const apiKeyInput = document.getElementById('apiKey');
const dashboardApiKeyInput = document.getElementById('dashboardApiKey');
const status = document.getElementById('status');

const updatedFromInput = document.getElementById('updatedFrom');
const updatedToInput = document.getElementById('updatedTo');
const vesselImoInput = document.getElementById('vesselImo');
const generateBtn = document.getElementById('generate');
const reportStatus = document.getElementById('reportStatus');

// Load saved keys
chrome.storage.sync.get(['apiKey', 'dashboardApiKey'], ({ apiKey, dashboardApiKey }) => {
  if (apiKey) apiKeyInput.value = apiKey;
  if (dashboardApiKey) dashboardApiKeyInput.value = dashboardApiKey;
});

// Save keys
document.getElementById('save').addEventListener('click', () => {
  const apiKey = apiKeyInput.value.trim();
  const dashboardApiKey = dashboardApiKeyInput.value.trim();
  chrome.storage.sync.set({ apiKey, dashboardApiKey }, () => {
    status.textContent = '✅ Saved.';
    status.className = 'status ok';
    setTimeout(() => {
      status.textContent = '';
      status.className = 'status';
    }, 1500);
  });
});

// Set status helper
function setReportStatus(text, type = 'info') {
  reportStatus.textContent = text;
  reportStatus.className = 'status ' + type;
}

// Generate PDF
generateBtn.addEventListener('click', () => {
  const updatedFrom = updatedFromInput.value;
  const updatedTo = updatedToInput.value;
  const vesselImo = vesselImoInput.value.trim();
  const includeClosed = document.getElementById('includeClosed').checked;

  // Build state list
  const states = ['open', 'new', 'With MAR/DGRM/GAMA', 'With RO'];
  if (includeClosed) {
    states.push('closed', 'pending close', 'pending reminder');
  }

  // Build filters — only send what's filled
  const filters = {
    state: states
  };
  if (updatedFrom) filters.updated_from = updatedFrom;
  if (updatedTo) filters.updated_to = updatedTo;
  if (vesselImo) filters.vessel_imo = vesselImo;

  generateBtn.disabled = true;
  setReportStatus('⏳ Generating PDF...', 'info');

  chrome.runtime.sendMessage(
    { type: 'zvl_generate_report', filters },
    (response) => {
      generateBtn.disabled = false;

      if (chrome.runtime.lastError) {
        setReportStatus('❌ ' + chrome.runtime.lastError.message, 'err');
        return;
      }
      if (!response) {
        setReportStatus('❌ No response from background.', 'err');
        return;
      }
      if (!response.ok) {
        setReportStatus('❌ ' + response.error, 'err');
        return;
      }
      setReportStatus('✅ PDF downloaded.', 'ok');
      setTimeout(() => setReportStatus(''), 3000);
    }
  );
});
