// Zammad Vessel Lookup — content script
// Adds a floating button to ticket pages, opens a search panel,
// queries the user's API, and offers to auto-fill Vessel Name / IMO fields.

(function () {
  'use strict';

  const API_BASE = ''; // unused — fetch happens in background.js (CORS bypass)
  let lastResults = [];
  let searchTimer = null;

  // ---------- UI ----------
  function buildUI() {
    if (document.getElementById('zvl-fab')) return;

    const fab = document.createElement('button');
    fab.id = 'zvl-fab';
    fab.title = 'Vessel lookup (drag to move)';
    fab.innerHTML = '⚓';
    document.body.appendChild(fab);

    const panel = document.createElement('div');
    panel.id = 'zvl-panel';
    panel.innerHTML = `
      <div class="zvl-header">
        <span>Vessel Lookup</span>
        <button class="zvl-close" title="Close">×</button>
      </div>
      <div class="zvl-body">
        <input type="text" class="zvl-input" placeholder="Type vessel name (min 2 chars)…" autocomplete="off" />
        <div class="zvl-status"></div>
        <ul class="zvl-results"></ul>
      </div>
      <div class="zvl-footer">
        <small>Click a result to fill the ticket fields.</small>
      </div>
    `;
    document.body.appendChild(panel);

    fab.addEventListener('click', () => togglePanel());
    panel.querySelector('.zvl-close').addEventListener('click', () => togglePanel(false));
    panel.querySelector('.zvl-input').addEventListener('input', onSearchInput);

    enableDrag(fab, panel);
    restorePosition(fab, panel);
  }

  // ---------- Drag & position persistence ----------
  function enableDrag(fab, panel) {
    let dragging = false;
    let moved = false;
    let startX, startY, startLeft, startTop;

    fab.addEventListener('mousedown', (e) => {
      if (e.button !== 0) return;
      dragging = true;
      moved = false;
      const rect = fab.getBoundingClientRect();
      startX = e.clientX;
      startY = e.clientY;
      startLeft = rect.left;
      startTop = rect.top;
      fab.style.transition = 'none';
      e.preventDefault();
    });

    document.addEventListener('mousemove', (e) => {
      if (!dragging) return;
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;
      if (Math.abs(dx) > 3 || Math.abs(dy) > 3) moved = true;
      const newLeft = clamp(startLeft + dx, 0, window.innerWidth - fab.offsetWidth);
      const newTop  = clamp(startTop  + dy, 0, window.innerHeight - fab.offsetHeight);
      fab.style.left = newLeft + 'px';
      fab.style.top  = newTop  + 'px';
      fab.style.right = 'auto';
      fab.style.bottom = 'auto';
      positionPanel(fab, panel);
    });

    document.addEventListener('mouseup', () => {
      if (!dragging) return;
      dragging = false;
      fab.style.transition = '';
      if (moved) {
        // Save position
        chrome.storage.sync.set({
          fabPos: { left: parseInt(fab.style.left, 10), top: parseInt(fab.style.top, 10) }
        });
        // Suppress the click that follows a drag
        fab.addEventListener('click', suppressOnce, { capture: true, once: true });
      }
    });

    function suppressOnce(e) { e.stopPropagation(); e.preventDefault(); }
  }

  function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }

  async function restorePosition(fab, panel) {
    const { fabPos } = await chrome.storage.sync.get('fabPos');
    if (fabPos && Number.isFinite(fabPos.left) && Number.isFinite(fabPos.top)) {
      fab.style.left = clamp(fabPos.left, 0, window.innerWidth - fab.offsetWidth) + 'px';
      fab.style.top  = clamp(fabPos.top,  0, window.innerHeight - fab.offsetHeight) + 'px';
      fab.style.right = 'auto';
      fab.style.bottom = 'auto';
      positionPanel(fab, panel);
    }
  }

  // Anchor panel to the FAB — opens above by default, flips below if no room
  function positionPanel(fab, panel) {
    const fabRect = fab.getBoundingClientRect();
    const panelW = 360;
    const panelH = 520;
    let left = fabRect.left + fabRect.width / 2 - panelW / 2;
    left = clamp(left, 8, window.innerWidth - panelW - 8);
    let top = fabRect.top - panelH - 12;
    if (top < 8) top = fabRect.bottom + 12; // flip below
    panel.style.left = left + 'px';
    panel.style.top  = top  + 'px';
    panel.style.right = 'auto';
    panel.style.bottom = 'auto';
  }

  function togglePanel(force) {
    const panel = document.getElementById('zvl-panel');
    const fab = document.getElementById('zvl-fab');
    if (!panel || !fab) return;
    const show = force === undefined ? !panel.classList.contains('open') : force;
    panel.classList.toggle('open', show);
    if (show) {
      positionPanel(fab, panel);
      const input = panel.querySelector('.zvl-input');
      input.focus();
      input.select();
    }
  }

  // ---------- Search ----------
  function onSearchInput(e) {
    const q = e.target.value.trim();
    clearTimeout(searchTimer);
    if (q.length < 2) {
      renderResults([]);
      setStatus('');
      return;
    }
    setStatus('Searching…');
    searchTimer = setTimeout(() => doSearch(q), 250);
  }

  async function doSearch(name) {
    try {
      const resp = await chrome.runtime.sendMessage({ type: 'zvl_search', name });
      if (!resp) { setStatus('❌ No response from background worker.'); return; }
      if (!resp.ok) { setStatus('❌ ' + resp.error); return; }
      lastResults = resp.data.results || [];
      if (!lastResults.length) setStatus('No vessels found.');
      else setStatus(`${lastResults.length} result(s)`);
      renderResults(lastResults);
    } catch (err) {
      setStatus('❌ Error: ' + err.message);
    }
  }

  function setStatus(msg) {
    const el = document.querySelector('#zvl-panel .zvl-status');
    if (el) el.textContent = msg;
  }

  function renderResults(results) {
    const ul = document.querySelector('#zvl-panel .zvl-results');
    if (!ul) return;
    ul.innerHTML = '';
    results.forEach((r) => {
      const li = document.createElement('li');
      li.className = 'zvl-result';
      li.innerHTML = `
        <div class="zvl-name">${escapeHtml(r.vessel_name || '')}</div>
        <div class="zvl-imo">IMO ${escapeHtml(r.vessel_imo || '')}</div>
      `;
      li.addEventListener('click', () => handleResultClick(r));
      ul.appendChild(li);
    });
  }

  // ---------- Autofill (with confirmation) ----------
  function handleResultClick(result) {
    const details = buildVesselDetails(result);

    const ok = confirm(
      `Fill the ticket fields with:\n\n` +
      `Vessel Name: ${result.vessel_name || '—'}\n` +
      `Vessel IMO:  ${result.vessel_imo || '—'}\n\n` +
      `Vessel Details:\n${details}\n\n` +
      `Continue?`
    );
    if (!ok) return;

    const filledName    = fillField(['vessel_name', 'vesselname', 'vessel-name'], result.vessel_name);
    const filledImo     = fillField(['vessel_imo', 'vesselimo', 'vessel-imo', 'imo'], result.vessel_imo);
    const filledDetails = fillField(['vessel_details', 'vesseldetails', 'vessel-details'], details);

    const filled = [filledName && 'Name', filledImo && 'IMO', filledDetails && 'Details'].filter(Boolean);
    const missing = [!filledName && 'Name', !filledImo && 'IMO', !filledDetails && 'Details'].filter(Boolean);

    if (missing.length === 0) {
      setStatus('✅ All fields filled.');
    } else if (filled.length > 0) {
      setStatus(`⚠️ Filled: ${filled.join(', ')}. Not found: ${missing.join(', ')}.`);
    } else {
      setStatus('❌ Could not find ticket fields. Copied to clipboard.');
      navigator.clipboard.writeText(
        `${result.vessel_name}\t${result.vessel_imo}\n${details}`
      ).catch(() => {});
    }
  }

  // Build the multi-line vessel_details summary
  function buildVesselDetails(r) {
    const today = new Date().toISOString().slice(0, 10); // YYYY-MM-DD
    const gt = r.gross_tonnage ? formatNumber(r.gross_tonnage) : '';
    const lines = [
      r.vessel_type     ? `Vessel Type: ${r.vessel_type}` : null,
      r.class_society   ? `Class Society: ${r.class_society}` : null,
      (gt || r.year_built) ? `GT: ${gt || '—'} | Built: ${r.year_built || '—'}` : null,
      r.ism_manager     ? `ISM Manager: ${r.ism_manager}${r.ism_manager_imo ? ` (IMO ${r.ism_manager_imo})` : ''}` : null,
      `Updated: ${today}`
    ];
    return lines.filter(Boolean).join('\n');
  }

  function formatNumber(v) {
    const n = Number(String(v).replace(/[^\d.-]/g, ''));
    if (!Number.isFinite(n)) return String(v);
    return n.toLocaleString('en-US');
  }

  // Tries to find a Zammad custom-field input by name attribute or surrounding label
  function fillField(possibleNames, value) {
    if (!value) return false;

    // Strategy 1: <input name="..."> by data-name or name attribute
    for (const n of possibleNames) {
      const el = document.querySelector(
        `input[name="${n}"], input[data-name="${n}"], textarea[name="${n}"]`
      );
      if (el) { setNativeValue(el, value); return true; }
    }

    // Strategy 2: label text match → sibling/descendant input
    const labels = document.querySelectorAll('label, .form-group label, .controls label');
    for (const lbl of labels) {
      const txt = (lbl.textContent || '').trim().toLowerCase();
      const wantsName    = possibleNames.some(n => n.includes('name'))    && txt.includes('vessel') && txt.includes('name');
      const wantsImo     = possibleNames.some(n => n.includes('imo'))     && txt.includes('imo')    && !txt.includes('manager');
      const wantsDetails = possibleNames.some(n => n.includes('details')) && txt.includes('vessel') && txt.includes('details');
      if (wantsName || wantsImo || wantsDetails) {
        const container = lbl.closest('.form-group, .controls, .row') || lbl.parentElement;
        const input = container && container.querySelector('input, textarea');
        if (input) { setNativeValue(input, value); return true; }
      }
    }
    return false;
  }

  // React/Vue-friendly value setter — fires native input event so Zammad sees the change
  function setNativeValue(el, value) {
    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
    setter.call(el, value);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => (
      { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
    ));
  }

  // ---------- Init ----------
  // Zammad is a SPA — re-check periodically that our UI is still mounted.
  buildUI();
  const obs = new MutationObserver(() => buildUI());
  obs.observe(document.body, { childList: true, subtree: true });
})();
