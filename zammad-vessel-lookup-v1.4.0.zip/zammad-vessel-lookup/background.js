// Background service worker — performs API fetches with elevated permissions,
// bypassing CORS restrictions that block content-script fetches.

const PSC_API_BASE = 'https://pscplatformalpha.onrender.com/api/ships/search';
const DASHBOARD_REPORT_URL = 'https://zammad-dashboard.onrender.com/api/v1/report';

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === 'zvl_search') {
    handleVesselSearch(msg, sendResponse);
    return true; // keep channel open for async sendResponse
  }

  if (msg?.type === 'zvl_generate_report') {
    handleGenerateReport(msg, sendResponse);
    return true;
  }

  return false;
});

// ---- Vessel search (existing) ----
async function handleVesselSearch(msg, sendResponse) {
  try {
    const { apiKey } = await chrome.storage.sync.get('apiKey');
    if (!apiKey) {
      sendResponse({ ok: false, error: 'No PSC API key set. Click the extension icon to configure.' });
      return;
    }
    const url = `${PSC_API_BASE}?name=${encodeURIComponent(msg.name)}`;
    const res = await fetch(url, { headers: { 'X-API-Key': apiKey } });
    if (res.status === 401) {
      sendResponse({ ok: false, error: 'Invalid PSC API key.' });
      return;
    }
    if (!res.ok) {
      sendResponse({ ok: false, error: `API error (${res.status})` });
      return;
    }
    const data = await res.json();
    sendResponse({ ok: true, data });
  } catch (err) {
    sendResponse({ ok: false, error: 'Network error: ' + err.message });
  }
}

// ---- Generate PDF report (new) ----
async function handleGenerateReport(msg, sendResponse) {
  try {
    const { dashboardApiKey } = await chrome.storage.sync.get('dashboardApiKey');
    if (!dashboardApiKey) {
      sendResponse({ ok: false, error: 'No Dashboard API key set. Click the extension icon to configure.' });
      return;
    }

    const body = {
      format: 'pdf',
      limit: 1000,
      filters: msg.filters || {}
    };

    const res = await fetch(DASHBOARD_REPORT_URL, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${dashboardApiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(body)
    });

    if (res.status === 401) {
      sendResponse({ ok: false, error: 'Invalid Dashboard API key.' });
      return;
    }
    if (!res.ok) {
      const txt = await res.text().catch(() => '');
      sendResponse({ ok: false, error: `API error (${res.status})${txt ? ': ' + txt.slice(0, 120) : ''}` });
      return;
    }

    // Receive PDF as blob, convert to data URL for chrome.downloads
    const blob = await res.blob();
    const dataUrl = await blobToDataUrl(blob);

    // Build filename
    const today = new Date().toISOString().slice(0, 10); // YYYY-MM-DD
    const filters = msg.filters || {};
    let suffix = today;
    if (filters.updated_from && filters.updated_to) {
      suffix = `${filters.updated_from}_to_${filters.updated_to}`;
    } else if (filters.updated_from) {
      suffix = `from_${filters.updated_from}`;
    } else if (filters.updated_to) {
      suffix = `until_${filters.updated_to}`;
    }
    if (filters.vessel_imo) {
      suffix += `_imo${filters.vessel_imo}`;
    }
    const filename = `maritime-report-${suffix}.pdf`;

    chrome.downloads.download(
      {
        url: dataUrl,
        filename: filename,
        saveAs: false
      },
      (downloadId) => {
        if (chrome.runtime.lastError) {
          sendResponse({ ok: false, error: 'Download failed: ' + chrome.runtime.lastError.message });
          return;
        }
        sendResponse({ ok: true, downloadId });
      }
    );
  } catch (err) {
    sendResponse({ ok: false, error: 'Network error: ' + err.message });
  }
}

// Helper: convert blob to data URL (service workers can't use URL.createObjectURL for downloads reliably)
function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(blob);
  });
}
