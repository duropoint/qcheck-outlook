// Euromar Toolkit — content script: receives vessel data from the side panel and fills Zammad ticket fields.
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === "zvl_fill") {
    sendResponse(fillVesselData(msg.vessel));
  }
  return false;
});

function fillVesselData(r) {
  const name    = r.vessel_name || "";
  const imo     = r.vessel_imo ? String(r.vessel_imo) : "";
  const details = buildVesselDetails(r);

  const filledName    = fillField(["vessel_name", "vesselname", "vessel-name"], name);
  const filledImo     = fillField(["vessel_imo", "vesselimo", "vessel-imo", "imo"], imo);
  const filledDetails = fillField(["vessel_details", "vesseldetails", "vessel-details"], details);

  const filled  = [filledName && "Name", filledImo && "IMO", filledDetails && "Details"].filter(Boolean);
  const missing = [!filledName && "Name", !filledImo && "IMO", !filledDetails && "Details"].filter(Boolean);

  if (missing.length === 0) return { ok: true,  msg: "All fields filled." };
  if (filled.length  > 0)  return { ok: true,  msg: `Filled: ${filled.join(", ")}. Not found: ${missing.join(", ")}.` };
  return { ok: false, msg: "Could not find ticket fields on this page." };
}

function buildVesselDetails(r) {
  const today = new Date().toISOString().slice(0, 10);
  const gt    = r.gross_tonnage ? formatNumber(r.gross_tonnage) : "";
  return [
    r.vessel_type   ? `Vessel Type: ${r.vessel_type}`     : null,
    r.class_society ? `Class Society: ${r.class_society}` : null,
    (gt || r.year_built) ? `GT: ${gt || "—"} | Built: ${r.year_built || "—"}` : null,
    r.ism_manager   ? `ISM Manager: ${r.ism_manager}${r.ism_manager_imo ? ` (IMO ${r.ism_manager_imo})` : ""}` : null,
    `Updated: ${today}`
  ].filter(Boolean).join("\n");
}

function formatNumber(v) {
  const n = Number(String(v).replace(/[^\d.-]/g, ""));
  return Number.isFinite(n) ? n.toLocaleString("en-US") : String(v);
}

function fillField(possibleNames, value) {
  if (!value) return false;

  for (const n of possibleNames) {
    const el = document.querySelector(
      `input[name="${n}"], input[data-name="${n}"], textarea[name="${n}"]`
    );
    if (el) { setNativeValue(el, value); return true; }
  }

  const labels = document.querySelectorAll("label, .form-group label, .controls label");
  for (const lbl of labels) {
    const txt          = (lbl.textContent || "").trim().toLowerCase();
    const wantsName    = possibleNames.some(n => n.includes("name"))    && txt.includes("vessel") && txt.includes("name");
    const wantsImo     = possibleNames.some(n => n.includes("imo"))     && txt.includes("imo")    && !txt.includes("manager");
    const wantsDetails = possibleNames.some(n => n.includes("details")) && txt.includes("vessel") && txt.includes("details");
    if (wantsName || wantsImo || wantsDetails) {
      const container = lbl.closest(".form-group, .controls, .row") || lbl.parentElement;
      const input     = container && container.querySelector("input, textarea");
      if (input) { setNativeValue(input, value); return true; }
    }
  }
  return false;
}

function setNativeValue(el, value) {
  const proto  = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
  const setter = Object.getOwnPropertyDescriptor(proto, "value").set;
  setter.call(el, value);
  el.dispatchEvent(new Event("input",  { bubbles: true }));
  el.dispatchEvent(new Event("change", { bubbles: true }));
  el.dispatchEvent(new Event("blur",   { bubbles: true }));
}
