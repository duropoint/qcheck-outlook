chrome.action.onClicked.addListener((tab) => {
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => {
      const cb = document.querySelectorAll('.ui-chkbox-box');
      for (let i = 0; i < cb.length; i++) {
        if (!cb[i].querySelector('.ui-icon-check')) {
          cb[i].click();
        }
      }
    }
  });
});
