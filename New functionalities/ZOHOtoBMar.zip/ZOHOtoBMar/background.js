chrome.runtime.onInstalled.addListener(() => {
  console.log("🚀 Zoho → BMAR Auto Complete Extension Installed!");
});

// Relay messages between popup and content script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // Forward progress updates to popup
  if (message.type === "progress" || message.type === "complete" || message.type === "error") {
    chrome.runtime.sendMessage(message);
  }
  
  return true;
});