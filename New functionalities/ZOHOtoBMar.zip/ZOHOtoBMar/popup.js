let copiedData = null;
let selectedFiles = null;
let additionalOptions = {
  addRuleCapacity: false,
  stcwRule: "",
  capacity: "",
  addTankerCapacity: false,
  cop1Rule: "",
  cop2Rule: "",
  tankerCapacity: "",
  medicalNationality: ""
};

// Mapeamento de Rules para Capacities (apenas para COC)
const ruleCapacityMap = {
  "II/1": ["Officer in charge of a navigational watch"],
  "II/2": ["Master", "Chief Mate"],
  "II/3": ["Master on ships of less than 500 GT, engaged on near coastal voyages", "Chief Mate"],
  "III/1": ["Officer in Charge of an Engineering Watch"],
  "III/2": ["Chief Engineer Officer", "Second Engineer Officer"],
  "III/3": ["Chief Engineer Officer", "Second Engineer Officer"],
  "III/6": ["Electrotechnical Officer"]
};

// Event listeners
document.getElementById("copyFromZoho").addEventListener("click", copyFromZoho);
document.getElementById("folderPicker").addEventListener("change", handleFolderSelect);
document.getElementById("autoExecute").addEventListener("click", executeAutomation);

// Toggle rule/capacity dropdowns (COC)
document.getElementById("addRuleCapacity").addEventListener("change", (e) => {
  const dropdowns = document.getElementById("ruleCapacityDropdowns");
  dropdowns.style.display = e.target.checked ? "block" : "none";
  additionalOptions.addRuleCapacity = e.target.checked;
});

// Toggle tanker capacity dropdown
document.getElementById("addTankerCapacity").addEventListener("change", (e) => {
  const dropdown = document.getElementById("tankerCapacityDropdown");
  dropdown.style.display = e.target.checked ? "block" : "none";
  additionalOptions.addTankerCapacity = e.target.checked;
});

// Update capacity options when rule changes (COC)
document.getElementById("stcwRuleSelect").addEventListener("change", (e) => {
  const rule = e.target.value;
  additionalOptions.stcwRule = rule;
  
  const capacitySelect = document.getElementById("capacitySelect");
  const hint = document.getElementById("capacityHint");
  
  // Clear previous options
  capacitySelect.innerHTML = '<option value="">-Selecionar Capacity-</option>';
  
  if (rule && ruleCapacityMap[rule]) {
    const capacities = ruleCapacityMap[rule];
    capacities.forEach(cap => {
      const option = document.createElement("option");
      option.value = cap;
      option.textContent = cap;
      capacitySelect.appendChild(option);
    });
    
    if (capacities.length === 1) {
      hint.textContent = "⚠️ Esta Rule tem apenas 1 opção";
      capacitySelect.value = capacities[0];
      additionalOptions.capacity = capacities[0];
    } else {
      hint.textContent = `💡 Escolhe entre ${capacities.length} opções`;
    }
  } else {
    hint.textContent = "";
  }
});

// Save selected capacity (COC)
document.getElementById("capacitySelect").addEventListener("change", (e) => {
  additionalOptions.capacity = e.target.value;
});

// Save COP1 Rule
document.getElementById("cop1RuleSelect").addEventListener("change", (e) => {
  additionalOptions.cop1Rule = e.target.value;
});

// Save COP2 Rule
document.getElementById("cop2RuleSelect").addEventListener("change", (e) => {
  additionalOptions.cop2Rule = e.target.value;
});

// Save selected tanker capacity
document.getElementById("tankerCapacitySelect").addEventListener("change", (e) => {
  additionalOptions.tankerCapacity = e.target.value;
});

// Save medical nationality
document.getElementById("medicalNationality").addEventListener("input", (e) => {
  additionalOptions.medicalNationality = e.target.value;
  console.log("🌍 Medical Nationality guardada:", additionalOptions.medicalNationality);
});

document.getElementById("medicalNationality").addEventListener("change", (e) => {
  additionalOptions.medicalNationality = e.target.value;
  console.log("🌍 Medical Nationality guardada (change):", additionalOptions.medicalNationality);
});

// Restaurar dados ao abrir popup
chrome.storage.local.get(["savedFields", "savedFiles"], (data) => {
  if (data.savedFields) {
    copiedData = data.savedFields;
    showDataSummary(copiedData);
    updateStepStatus("stepCopy", "completed");
  }
  if (data.savedFiles) {
    selectedFiles = data.savedFiles;
    updateStepStatus("stepDocs", "completed");
  }
  checkReadyToExecute();
});

async function copyFromZoho() {
  showStatus("📄 Copiando dados do Zoho...", "info");
  updateStepStatus("stepCopy", "active");

  const tabs = await chrome.tabs.query({ currentWindow: true });
  const zohoTab = tabs.find(tab => tab.active && tab.url.includes("zoho.com"));

  if (!zohoTab) {
    showStatus("❌ Abre o formulário no Zoho primeiro!", "error");
    updateStepStatus("stepCopy", "");
    return;
  }

  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: zohoTab.id, allFrames: true },
      func: extractZohoData
    });

    let fields = {};
    for (const frame of results) {
      const r = frame?.result || {};
      const filledR = Object.values(r).filter(v => v && String(v).length).length;
      const filledCur = Object.values(fields).filter(v => v && String(v).length).length;
      if (filledR > filledCur) fields = r;
    }

    if (!fields || (!fields["First Name"] && !fields["Last Name"])) {
      showStatus("❌ Nenhum dado encontrado. Confirma que o registo está aberto.", "error");
      updateStepStatus("stepCopy", "");
      return;
    }

    copiedData = fields;
    await chrome.storage.local.set({ savedFields: fields });
    
    showDataSummary(fields);
    showStatus("✅ Dados copiados com sucesso!", "success");
    updateStepStatus("stepCopy", "completed");
    checkReadyToExecute();

  } catch (error) {
    console.error("Erro ao copiar:", error);
    showStatus("❌ Erro ao copiar dados: " + error.message, "error");
    updateStepStatus("stepCopy", "");
  }
}

function extractZohoData() {
  const q = (s, root = document) => root.querySelector(s);
  const getVal = (...sels) => {
    for (const s of sels) {
      const el = q(s);
      if (el) return (el.value ?? el.textContent ?? "").trim();
    }
    return "";
  };
  const getEl = (...sels) => {
    for (const s of sels) {
      const el = q(s);
      if (el) return el;
    }
    return null;
  };
  const getSelect = (...sels) => {
    const el = getEl(...sels);
    if (!el) return "";
    const optText = el.selectedOptions && el.selectedOptions[0] ? el.selectedOptions[0].text : "";
    return (optText || el.value || "").trim();
  };
  const getDateBy = (legacyName, ...hints) => {
    let v = getVal(`input[name="${legacyName}"]`);
    if (v) return v;
    v = getVal('input[type="date"]');
    if (v) return v;
    const tokens = hints.join(" ").toLowerCase();
    const inputs = Array.from(document.querySelectorAll('input'));
    for (const inp of inputs) {
      const pl = (inp.getAttribute('placeholder') || "").toLowerCase();
      const al = (inp.getAttribute('aria-label') || "").toLowerCase();
      if (tokens && (tokens.split(/\s+/).every(t => al.includes(t) || pl.includes(t)))) {
        if (inp.value) return inp.value.trim();
      }
    }
    return "";
  };

  const data = {};

  // Nomes
  data["First Name"] = getVal('input[name="Name"][complink="Name_First"]', 'input[complink="Name_First"]', 'input[aria-label*="first" i]');
  data["Last Name"] = getVal('input[name="Name"][complink="Name_Last"]', 'input[complink="Name_Last"]', 'input[aria-label*="last" i]');

  // Single-line fields
  data["Ship"] = getVal('input[name="SingleLine"]', 'input[placeholder*="Ship" i]', 'input[aria-label*="Ship" i]');
  data["Passport Number"] = getVal('input[name="SingleLine1"]', 'input[placeholder*="Passport" i]', 'input[aria-label*="Passport" i]');
  data["Person in Charge"] = getVal('input[name="SingleLine2"]', 'input[aria-label*="person in charge" i]');
  data["STCW Rule"] = getVal('input[name="SingleLine3"]', 'input[aria-label*="stcw" i]');
  data["COC Number"] = getVal('input[name="SingleLine4"]', 'input[placeholder*="COC" i]');
  data["COC Endorsement Number"] = getVal('input[name="SingleLine5"]', 'input[aria-label*="endorsement" i]');
  data["GOC Number"] = getVal('input[name="SingleLine6"]', 'input[placeholder*="GMDSS" i], input[placeholder*="GOC" i]');
  data["GOC Endorsement Number"] = getVal('input[name="SingleLine7"]', 'input[aria-label*="endorsement" i]');
  data["COP1 Number"] = getVal('input[name="SingleLine8"]', 'input[placeholder*="COP1" i]');
  data["COP2 Number"] = getVal('input[name="SingleLine9"]', 'input[placeholder*="COP2" i]');

  data["Invoice"] = "Applicant";

  // Dropdowns
  data["Capacity"] = getSelect('select[name="Dropdown"]', 'select[aria-label*="capacity" i]');
  data["Sex"] = getSelect('select[name="Dropdown1"]', 'select[aria-label*="sex" i]');
  data["Country of Origin"] = getSelect('select[name="Dropdown2"]', 'select[aria-label*="country" i]');
  data["Endorsement Physical Format"] = getSelect('select[name="Dropdown16"]');
  data["Medical Form"] = getSelect('select[name="Dropdown3"]', 'select[aria-label*="medical" i]');
  data["Record of Knowledge"] = getSelect('select[name="Dropdown4"]');
  data["COC Issued By"] = getSelect('select[name="Dropdown8"]');
  data["COC Endorsement Issued By"] = getSelect('select[name="Dropdown9"]');
  data["GOC Issued By"] = getSelect('select[name="Dropdown10"]');
  data["GOC Endorsement Issued By"] = getSelect('select[name="Dropdown11"]');
  data["COP1 Issued By"] = getSelect('select[name="Dropdown12"]');
  data["COP2 Issued By"] = getSelect('select[name="Dropdown13"]');

  // Dates
  const dateMap = {
    "Date": "Birthdate", "Date1": "LOC w/ signature", "Date2": "Passport Validity",
    "Date3": "Join Date", "Date4": "Medical Issuance date", "Date5": "Medical Expiry",
    "Date6": "ROK received", "Date7": "Application date", "Date8": "Valid verification",
    "Date11": "COC Issuance", "Date12": "COC Expiry", "Date13": "COC Endorsement Issuance",
    "Date14": "COC Endorsement Expiry", "Date15": "GOC Issuance", "Date16": "GOC Expiry",
    "Date17": "GOC Endorsement Issuance", "Date18": "GOC Endorsement Expiry",
    "Date19": "COP1 Issuance", "Date20": "COP1 Expiry", "Date21": "COP2 Issuance",
    "Date22": "COP2 Expiry", "Date33": "COC Revalidation date", "Date34": "COC Revalidation Expiry date",
    "Date36": "GOC Revalidation date", "Date35": "GOC Revalidation Expiry date"
  };

  const dateHints = {
    "Birthdate": ["birth", "date"], "Passport Validity": ["passport", "valid"],
    "COC Issuance": ["coc", "issu"], "COC Expiry": ["coc", "expiry"],
    "COC Endorsement Issuance": ["coc", "endorsement", "issu"],
    "COC Endorsement Expiry": ["coc", "endorsement", "expiry"],
    "GOC Issuance": ["goc", "gmdss", "issu"], "GOC Expiry": ["goc", "gmdss", "expiry"],
    "GOC Endorsement Issuance": ["goc", "endorsement", "issu"],
    "GOC Endorsement Expiry": ["goc", "endorsement", "expiry"],
    "COP1 Issuance": ["cop1", "issu"], "COP1 Expiry": ["cop1", "expiry"],
    "COP2 Issuance": ["cop2", "issu"], "COP2 Expiry": ["cop2", "expiry"],
    "Medical Issuance date": ["medical", "issu"], "Medical Expiry": ["medical", "expiry"],
    "COC Revalidation date": ["coc", "revalid"],
    "COC Revalidation Expiry date": ["coc", "revalid", "expiry"],
    "GOC Revalidation date": ["goc", "revalid"],
    "GOC Revalidation Expiry date": ["goc", "revalid", "expiry"]
  };

  for (const legacy in dateMap) {
    const label = dateMap[legacy];
    data[label] = getDateBy(legacy, ...(dateHints[label] || []));
  }

  // Multi-line & Email
  data["Invoice Address"] = getVal('textarea[name="MultiLine"]', 'textarea[aria-label*="invoice" i]');
  data["Dispatch Address"] = getVal('textarea[name="MultiLine1"]', 'textarea[aria-label*="dispatch" i]');
  data["PIC Email"] = getVal('input[name="Email"]', 'input[type="email"]');

  return data;
}

async function handleFolderSelect(e) {
  const files = [...e.target.files];
  
  const tipos = {
    seamans: f => f.name.toLowerCase().startsWith("03"),
    pass: f => f.name.toLowerCase().startsWith("02"),
    coc: f => f.name.toLowerCase().startsWith("04_coc"),
    gmdss: f => f.name.toLowerCase().startsWith("04_gmdss") || f.name.toLowerCase().startsWith("04_goc"),
    tankerChem: f => f.name.toLowerCase().startsWith("04_tankerchem"),
    tankerOil: f => f.name.toLowerCase().startsWith("04_tankeroil"),
    tanker: f => f.name.toLowerCase().startsWith("04_tanker") && 
                 !f.name.toLowerCase().startsWith("04_tankerchem") &&
                 !f.name.toLowerCase().startsWith("04_tankeroil") &&
                 !f.name.toLowerCase().startsWith("04_coc") &&
                 !f.name.toLowerCase().startsWith("04_gmdss") &&
                 !f.name.toLowerCase().startsWith("04_goc"),
    med: f => f.name.toLowerCase().startsWith("05"),
    rok: f => f.name.toLowerCase().startsWith("06"),
    loc: f => f.name.toLowerCase().startsWith("12")
  };

  const documentos = {};
  
  console.log("🔍 DEBUG - Ficheiros selecionados:");
  files.forEach(f => console.log(`   ${f.name}`));
  
  for (const [tipo, matchFn] of Object.entries(tipos)) {
    const ficheiro = files.find(matchFn);
    if (!ficheiro) continue;

    console.log(`✅ ${ficheiro.name} → tipo: "${tipo}"`);

    const base64 = await new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const b64 = e.target.result.split(",")[1];
        resolve(b64);
      };
      reader.readAsDataURL(ficheiro);
    });

    documentos[tipo] = { name: ficheiro.name, data: base64 };
  }

  selectedFiles = documentos;
  await chrome.storage.local.set({ savedFiles: documentos });
  
  const count = Object.keys(documentos).length;
  showStatus(`✅ ${count} documento(s) selecionado(s)`, "success");
  updateStepStatus("stepDocs", "completed");
  checkReadyToExecute();
}

function checkReadyToExecute() {
  const btn = document.getElementById("autoExecute");
  if (copiedData && selectedFiles) {
    btn.disabled = false;
    updateStepStatus("stepAuto", "active");
  } else {
    btn.disabled = true;
    updateStepStatus("stepAuto", "");
  }
}

async function executeAutomation() {
  if (!copiedData || !selectedFiles) {
    showStatus("❌ Falta copiar dados ou selecionar documentos!", "error");
    return;
  }

  // 🔍 Capturar TODOS os valores dos inputs E checkboxes antes de enviar
  const medicalInput = document.getElementById("medicalNationality");
  const addRuleCapacityCheckbox = document.getElementById("addRuleCapacity");
  const stcwRuleInput = document.getElementById("stcwRuleSelect");
  const capacityInput = document.getElementById("capacitySelect");
  const addTankerCapacityCheckbox = document.getElementById("addTankerCapacity");
  const cop1RuleInput = document.getElementById("cop1RuleSelect");
  const cop2RuleInput = document.getElementById("cop2RuleSelect");
  const tankerCapacityInput = document.getElementById("tankerCapacitySelect");
  
  // Atualizar additionalOptions com os valores atuais
  if (medicalInput) additionalOptions.medicalNationality = medicalInput.value || "";
  if (addRuleCapacityCheckbox) additionalOptions.addRuleCapacity = addRuleCapacityCheckbox.checked;
  if (stcwRuleInput) additionalOptions.stcwRule = stcwRuleInput.value || "";
  if (capacityInput) additionalOptions.capacity = capacityInput.value || "";
  if (addTankerCapacityCheckbox) additionalOptions.addTankerCapacity = addTankerCapacityCheckbox.checked;
  if (cop1RuleInput) additionalOptions.cop1Rule = cop1RuleInput.value || "";
  if (cop2RuleInput) additionalOptions.cop2Rule = cop2RuleInput.value || "";
  if (tankerCapacityInput) additionalOptions.tankerCapacity = tankerCapacityInput.value || "";
  
  // Mostrar no status o que vai ser enviado
  console.log("📦 additionalOptions finais:", additionalOptions);
  showStatus(`📤 Enviando... (Medical: "${additionalOptions.medicalNationality}")`, "info");

  const tabs = await chrome.tabs.query({ currentWindow: true });
  const bmarTab = tabs.find(tab => tab.active && tab.url.includes("bmar.pt"));

  if (!bmarTab) {
    showStatus("❌ Abre uma página do BMAR primeiro!", "error");
    return;
  }

  // Mostrar progresso
  document.getElementById("progressBar").style.display = "block";
  updateProgress(0);
  
  showStatus("🚀 Iniciando automação completa...", "info");

  try {
    console.log("📄 Verificando content script...");
    
    let scriptReady = false;
    try {
      const pingResponse = await new Promise((resolve, reject) => {
        chrome.tabs.sendMessage(bmarTab.id, { action: "ping" }, (response) => {
          if (chrome.runtime.lastError) {
            reject(chrome.runtime.lastError);
          } else {
            resolve(response);
          }
        });
      });
      
      if (pingResponse?.status === "pong") {
        scriptReady = true;
        console.log("✅ Content script respondeu ao ping");
      }
    } catch (e) {
      console.log("⚠️ Ping falhou, vou tentar injetar o script:", e.message);
    }
    
    if (!scriptReady) {
      try {
        await chrome.scripting.executeScript({
          target: { tabId: bmarTab.id },
          files: ['content.js']
        });
        console.log("✅ Content script injetado manualmente");
        await new Promise(r => setTimeout(r, 1000));
      } catch (e) {
        console.error("❌ Erro ao injetar content script:", e);
        showStatus("❌ Erro ao preparar automação. Recarrega a página do BMAR (F5) e tenta novamente.", "error");
        return;
      }
    }

    console.log("📤 Enviando comando de automação...");
    console.log("🌍 Medical Nationality sendo enviada:", additionalOptions.medicalNationality);
    console.log("📦 Objeto options completo:", additionalOptions);
    
    chrome.tabs.sendMessage(
      bmarTab.id,
      { 
        action: "automate", 
        fields: copiedData,
        documents: selectedFiles,
        options: additionalOptions
      },
      (response) => {
        if (chrome.runtime.lastError) {
          console.error("❌ Erro ao comunicar:", chrome.runtime.lastError);
          showStatus("❌ Erro ao comunicar. Recarrega a página do BMAR (F5) e tenta novamente.", "error");
        } else {
          console.log("✅ Automação iniciada:", response);
        }
      }
    );

  } catch (error) {
    showStatus("❌ Erro: " + error.message, "error");
    console.error(error);
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "progress") {
    updateProgress(message.percent);
    showStatus(message.message, "info");
  } else if (message.type === "complete") {
    updateProgress(100);
    showStatus("✅ Automação concluída com sucesso!", "success");
    updateStepStatus("stepAuto", "completed");
  } else if (message.type === "uploadComplete") {
    // Mostrar resumo detalhado do upload
    handleUploadComplete(message.results);
  } else if (message.type === "error") {
    showStatus("❌ Erro: " + message.message, "error");
  }
});

function handleUploadComplete(results) {
  const { success, failed } = results;
  const total = success.length + failed.length;
  
  if (failed.length === 0) {
    // Todos os uploads foram bem sucedidos
    updateProgress(100);
    showStatus(`✅ Todos os ${total} documentos foram enviados com sucesso!`, "success");
    updateStepStatus("stepAuto", "completed");
  } else if (success.length === 0) {
    // Todos os uploads falharam
    showStatus(`❌ Todos os ${total} documentos falharam no upload!`, "error");
    showRetryButton(failed);
  } else {
    // Alguns falharam
    showStatus(
      `⚠️ Upload parcial: ${success.length}/${total} documentos enviados. ${failed.length} falharam.`,
      "warning"
    );
    showRetryButton(failed);
  }
  
  // Mostrar detalhes no resumo
  showUploadSummary(results);
}

function showRetryButton(failedDocs) {
  // Adicionar botão de retry ao popup
  const btnGroup = document.querySelector('.btn-group');
  
  // Remover botão anterior se existir
  const oldRetryBtn = document.getElementById('retryFailedBtn');
  if (oldRetryBtn) oldRetryBtn.remove();
  
  const retryBtn = document.createElement('button');
  retryBtn.id = 'retryFailedBtn';
  retryBtn.textContent = `🔄 Tentar Novamente (${failedDocs.length} docs)`;
  retryBtn.style.cssText = `
    background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
    color: white;
    padding: 14px 20px;
    border: none;
    border-radius: 8px;
    font-size: 15px;
    font-weight: 600;
    cursor: pointer;
    margin-top: 10px;
  `;
  
  retryBtn.addEventListener('click', () => retryFailedUploads(failedDocs));
  btnGroup.appendChild(retryBtn);
}

async function retryFailedUploads(failedDocs) {
  showStatus(`🔄 Tentando reenviar ${failedDocs.length} documentos...`, "info");
  
  const tabs = await chrome.tabs.query({ currentWindow: true });
  const bmarTab = tabs.find(tab => tab.active && tab.url.includes("bmar.pt"));
  
  if (!bmarTab) {
    showStatus("❌ Abre uma página do BMAR primeiro!", "error");
    return;
  }
  
  // Reconstruir objeto de documentos apenas com os que falharam
  const docsToRetry = {};
  for (const doc of failedDocs) {
    // Procurar no selectedFiles original
    const originalDoc = selectedFiles[doc.type];
    if (originalDoc) {
      docsToRetry[doc.type] = originalDoc;
    }
  }
  
  // Enviar comando para fazer apenas upload (sem preencher formulários)
  chrome.tabs.sendMessage(
    bmarTab.id,
    { 
      action: "uploadOnly",
      documents: docsToRetry
    },
    (response) => {
      if (chrome.runtime.lastError) {
        console.error("❌ Erro ao comunicar:", chrome.runtime.lastError);
        showStatus("❌ Erro ao comunicar com a página.", "error");
      }
    }
  );
}

function showUploadSummary(results) {
  const summary = document.getElementById("dataSummary");
  summary.style.display = "block";
  
  let html = "<h4>📊 Resumo do Upload:</h4>";
  
  if (results.success.length > 0) {
    html += `<div style="margin-bottom: 12px;">`;
    html += `<strong style="color: #48bb78;">✅ Enviados (${results.success.length}):</strong>`;
    results.success.forEach(doc => {
      html += `<div class="data-item">
        <span class="data-label">${doc.type}:</span>
        <span class="data-value">${doc.name}</span>
      </div>`;
    });
    html += `</div>`;
  }
  
  if (results.failed.length > 0) {
    html += `<div>`;
    html += `<strong style="color: #f56565;">❌ Falharam (${results.failed.length}):</strong>`;
    results.failed.forEach(doc => {
      html += `<div class="data-item">
        <span class="data-label">${doc.type}:</span>
        <span class="data-value" style="color: #f56565;" title="${doc.reason}">${doc.name}</span>
      </div>`;
    });
    html += `</div>`;
  }
  
  summary.innerHTML = html;
}

function updateProgress(percent) {
  document.getElementById("progressFill").style.width = percent + "%";
}

function showStatus(message, type) {
  const status = document.getElementById("status");
  status.textContent = message;
  status.className = type;
  status.style.display = "block";
}

function updateStepStatus(stepId, status) {
  const step = document.getElementById(stepId);
  step.className = "step " + status;
}

function showDataSummary(data) {
  const summary = document.getElementById("dataSummary");
  summary.style.display = "block";
  
  let html = "<h4>📋 Dados Copiados:</h4>";
  
  const importantFields = [
    "First Name", "Last Name", "Birthdate", "Sex", "Passport Number", 
    "Country of Origin", "Ship", "Medical Expiry"
  ];
  
  for (const field of importantFields) {
    if (data[field]) {
      html += `
        <div class="data-item">
          <span class="data-label">${field}:</span>
          <span class="data-value">${data[field]}</span>
        </div>
      `;
    }
  }
  
  const certs = [];
  if (data["COC Number"]) certs.push("COC");
  if (data["GOC Number"]) certs.push("GMDSS");
  if (data["COP1 Number"]) certs.push("COP1");
  if (data["COP2 Number"]) certs.push("COP2");
  
  if (certs.length > 0) {
    html += `
      <div class="data-item">
        <span class="data-label">Certificados:</span>
        <span class="data-value">${certs.join(", ")}</span>
      </div>
    `;
  }
  
  summary.innerHTML = html;
}