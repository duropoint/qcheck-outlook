# Seafarers → Zoho BMAR Bridge

Extensão Chrome que transfere dados extraídos do Seafarers Panel para o formulário Zoho BMAR.

## Instalação

1. Descompacta o ficheiro ZIP
2. Abre `chrome://extensions/` no Chrome
3. Ativa o "Modo de programador" (canto superior direito)
4. Clica "Carregar sem compactação"
5. Seleciona a pasta `seafarers-zoho-bridge`

## Utilização

1. Vai ao Seafarers Panel ([Production](https://seafarers.eu-registry.com/) ou [Test](https://seafarers-web-test.idego.io/))
2. Processa um PDF de seafarer
3. Na página de revisão, clica no botão **"Enviar para Zoho BMAR"**
4. O formulário Zoho abre automaticamente com os dados prontos
5. Clica **"Preencher Formulário"** para auto-preencher todos os campos

## Campos Preenchidos

- Ship, Name, Sex, Birthdate, Country of Origin
- Passport Number, Passport Validity
- Invoice Address
- COC (Number, Dates, Issued By, Revalidation)
- COC Endorsement (Number, Dates, Issued By)
- GOC (Number, Dates, Issued By, Revalidation)
- GOC Endorsement (Number, Dates, Issued By)
- COP-1 e COP-2 (Number, Dates, Issued By)

## Versão

1.7.0
