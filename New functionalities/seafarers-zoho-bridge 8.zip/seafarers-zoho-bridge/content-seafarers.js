// Content script for Seafarers Panel
// Extracts data and provides button to send to Zoho

(function() {
  'use strict';

  // Wait for page to fully load
  function init() {
    // Check if we're on the review/confirmation page
    const pageTitle = document.querySelector('h2');
    if (!pageTitle || !pageTitle.textContent.includes('Review Extracted Data')) {
      return;
    }

    // Add the transfer button
    addTransferButton();
  }

  function addTransferButton() {
    // Find the submit button or form actions area
    const submitBtn = document.querySelector('button[type="submit"]');
    if (!submitBtn) return;

    // Check if button already exists
    if (document.getElementById('zoho-transfer-btn')) return;

    // Create the transfer button
    const transferBtn = document.createElement('button');
    transferBtn.id = 'zoho-transfer-btn';
    transferBtn.type = 'button';
    transferBtn.className = 'zoho-transfer-btn';
    transferBtn.innerHTML = `
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M5 12h14"></path>
        <path d="m12 5 7 7-7 7"></path>
      </svg>
      Enviar para Zoho BMAR
    `;

    transferBtn.addEventListener('click', handleTransfer);

    // Insert before submit button
    submitBtn.parentNode.insertBefore(transferBtn, submitBtn);
  }

  function extractData() {
    const getValue = (id) => {
      const el = document.getElementById(id);
      if (!el) return '';
      return el.value || '';
    };

    // Helper to format dates to YYYY-MM-DD for Zoho
    const formatDateForZoho = (dateStr) => {
      if (!dateStr || dateStr === '' || dateStr.includes('YYYY')) return '';
      
      // Handle both YYYY/MM/DD and YYYY-MM-DD formats
      const normalized = dateStr.replace(/\//g, '-');
      const parts = normalized.split('-');
      if (parts.length !== 3) return '';
      
      const [year, month, day] = parts;
      
      // Ensure proper padding with zeros
      const paddedMonth = month.padStart(2, '0');
      const paddedDay = day.padStart(2, '0');
      
      // Return in YYYY-MM-DD format (the only format Zoho accepts)
      return `${year}-${paddedMonth}-${paddedDay}`;
    };

    // Get full name
    const fullName = getValue('passport_name');

    // Extract ship name from the combobox
    const shipInput = document.getElementById('ship_search');
    const shipName = shipInput ? shipInput.value : '';

    // Extract invoice recipient
    const invoiceInput = document.getElementById('invoice_recipient_search');
    const invoiceRecipient = invoiceInput ? invoiceInput.value : '';

    const data = {
      // Processing Context
      ship: shipName,
      invoiceRecipient: invoiceRecipient,

      // Passport / Personal
      fullName: fullName,
      sex: getValue('passport_sex'),
      birthdate: formatDateForZoho(getValue('passport_birthdate')),
      countryOfOrigin: getValue('passport_country'),
      passportNumber: getValue('passport_number'),
      passportValidity: formatDateForZoho(getValue('passport_validity')),

      // Medical Certificate
      medicalIssuanceDate: formatDateForZoho(getValue('mc_issue_date')),
      medicalExpiryDate: formatDateForZoho(getValue('mc_expiry_date')),

      // COC
      cocNumber: getValue('coc_number'),
      cocIssuanceDate: formatDateForZoho(getValue('coc_issuance_date')),
      cocExpiryDate: formatDateForZoho(getValue('coc_expiry_date')),
      cocIssuedBy: getValue('coc_issued_by'),
      cocRevalidationIssuanceDate: formatDateForZoho(getValue('coc_revalidation_issuance_date')),
      cocRevalidationExpiryDate: formatDateForZoho(getValue('coc_revalidation_expiry_date')),

      // COC Endorsement
      cocEndorsementNumber: getValue('coc_endorsement_number'),
      cocEndorsementIssuanceDate: formatDateForZoho(getValue('coc_endorsement_issuance_date')),
      cocEndorsementExpiryDate: formatDateForZoho(getValue('coc_endorsement_expiry_date')),
      cocEndorsementIssuedBy: getValue('coc_endorsement_issued_by'),

      // GOC
      gocNumber: getValue('goc_number'),
      gocIssuanceDate: formatDateForZoho(getValue('goc_issuance_date')),
      gocExpiryDate: formatDateForZoho(getValue('goc_expiry_date')),
      gocIssuedBy: getValue('goc_issued_by'),
      gocRevalidationIssuanceDate: formatDateForZoho(getValue('goc_revalidation_issuance_date')),
      gocRevalidationExpiryDate: formatDateForZoho(getValue('goc_revalidation_expiry_date')),

      // GOC Endorsement
      gocEndorsementNumber: getValue('goc_endorsement_number'),
      gocEndorsementIssuanceDate: formatDateForZoho(getValue('goc_endorsement_issuance_date')),
      gocEndorsementExpiryDate: formatDateForZoho(getValue('goc_endorsement_expiry_date')),
      gocEndorsementIssuedBy: getValue('goc_endorsement_issued_by'),

      // COP 1
      cop1Number: getValue('cop1_number'),
      cop1IssuanceDate: formatDateForZoho(getValue('cop1_issuance_date')),
      cop1ExpiryDate: formatDateForZoho(getValue('cop1_expiry_date')),
      cop1IssuedBy: getValue('cop1_issued_by'),

      // COP 2
      cop2Number: getValue('cop2_number'),
      cop2IssuanceDate: formatDateForZoho(getValue('cop2_issuance_date')),
      cop2ExpiryDate: formatDateForZoho(getValue('cop2_expiry_date')),
      cop2IssuedBy: getValue('cop2_issued_by'),

      // Metadata
      extractedAt: new Date().toISOString()
    };

    return data;
  }

  function handleTransfer() {
    const btn = document.getElementById('zoho-transfer-btn');
    
    try {
      // Extract data
      const data = extractData();
      
      // Validate minimum required data
      if (!data.fullName || data.fullName.trim() === '') {
        showNotification('Erro: Nome do marítimo não encontrado', 'error');
        return;
      }

      // Encode data as base64 and pass via URL hash
      const encodedData = btoa(encodeURIComponent(JSON.stringify(data)));
      
      // Update button state
      btn.innerHTML = `
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <polyline points="20 6 9 17 4 12"></polyline>
        </svg>
        Dados copiados!
      `;
      btn.classList.add('success');

      showNotification(`Dados de ${data.fullName} prontos para transferência`, 'success');

      // Open Zoho form in new tab with data in URL hash
      setTimeout(() => {
        window.open(`https://forms.zoho.com/europeanmarlda/form/BMAR#seafarerData=${encodedData}`, '_blank');
      }, 500);

      // Auto-click "Confirm Data" button after opening Zoho
      setTimeout(() => {
        // Try to find the Confirm Data button by various selectors
        const confirmBtn = document.querySelector('button[type="submit"]') ||
                          document.querySelector('input[type="submit"]') ||
                          Array.from(document.querySelectorAll('button')).find(b => 
                            b.textContent.toLowerCase().includes('confirm')
                          );
        
        if (confirmBtn) {
          console.log('[Zoho Bridge] Clicking Confirm Data button...');
          confirmBtn.click();
        } else {
          console.log('[Zoho Bridge] Confirm Data button not found');
        }
      }, 800);

      // Reset button after delay
      setTimeout(() => {
        btn.innerHTML = `
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M5 12h14"></path>
            <path d="m12 5 7 7-7 7"></path>
          </svg>
          Enviar para Zoho BMAR
        `;
        btn.classList.remove('success');
      }, 3000);

    } catch (error) {
      console.error('Error extracting data:', error);
      showNotification('Erro ao extrair dados: ' + error.message, 'error');
    }
  }

  function showNotification(message, type) {
    // Remove existing notification
    const existing = document.querySelector('.seafarer-notification');
    if (existing) existing.remove();

    const notification = document.createElement('div');
    notification.className = `seafarer-notification ${type}`;
    notification.textContent = message;
    document.body.appendChild(notification);

    // Auto remove after 4 seconds
    setTimeout(() => {
      notification.classList.add('fade-out');
      setTimeout(() => notification.remove(), 300);
    }, 4000);
  }

  // Initialize when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // Also try after a short delay (for dynamic content)
  setTimeout(init, 1000);
})();
