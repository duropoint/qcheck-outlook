// Import PDF.js
import * as pdfjsLib from './pdf.mjs';

// Configure PDF.js worker
pdfjsLib.GlobalWorkerOptions.workerSrc = './pdf.worker.mjs';

let uploadedFiles = [];
let extractedData = null;

// Elementos DOM
const dropZone = document.getElementById('dropZone');
const fileInput = document.getElementById('fileInput');
const filesList = document.getElementById('filesList');
const extractedDataDiv = document.getElementById('extractedData');
const statusDiv = document.getElementById('status');
const extractBtn = document.getElementById('extractBtn');
const uploadBtn = document.getElementById('uploadBtn');
const folderPathInput = document.getElementById('folderPath');

// Event Listeners
dropZone.addEventListener('click', () => fileInput.click());
dropZone.addEventListener('dragover', handleDragOver);
dropZone.addEventListener('dragleave', handleDragLeave);
dropZone.addEventListener('drop', handleDrop);
fileInput.addEventListener('change', handleFileSelect);
extractBtn.addEventListener('click', extractAndFill);
uploadBtn.addEventListener('click', uploadToSharePoint);

// Listener para receber o nome do navio da página
window.addEventListener('message', (event) => {
  if (event.data.type === 'SHIP_NAME_EXTRACTED') {
    if (extractedData) {
      extractedData.shipName = event.data.shipName;
      console.log('Nome do navio recebido:', event.data.shipName);
    }
  }
});

function handleDragOver(e) {
  e.preventDefault();
  e.stopPropagation();
  dropZone.classList.add('drag-over');
}

function handleDragLeave(e) {
  e.preventDefault();
  e.stopPropagation();
  dropZone.classList.remove('drag-over');
}

function handleDrop(e) {
  e.preventDefault();
  e.stopPropagation();
  dropZone.classList.remove('drag-over');
  
  const files = Array.from(e.dataTransfer.files).filter(f => f.type === 'application/pdf');
  addFiles(files);
}

function handleFileSelect(e) {
  const files = Array.from(e.target.files);
  addFiles(files);
}

function addFiles(files) {
  // Limitar a 4 ficheiros
  const availableSlots = 4 - uploadedFiles.length;
  const filesToAdd = files.slice(0, availableSlots);
  
  uploadedFiles.push(...filesToAdd);
  
  if (uploadedFiles.length >= 4) {
    showStatus('Máximo de 4 ficheiros atingido', 'info');
  }
  
  renderFilesList();
  extractBtn.disabled = uploadedFiles.length === 0;
}

function removeFile(index) {
  uploadedFiles.splice(index, 1);
  renderFilesList();
  extractBtn.disabled = uploadedFiles.length === 0;
  
  if (uploadedFiles.length === 0) {
    extractedDataDiv.classList.add('hidden');
    uploadBtn.disabled = true;
  }
}

function renderFilesList() {
  if (uploadedFiles.length === 0) {
    filesList.classList.add('hidden');
    return;
  }
  
  filesList.classList.remove('hidden');
  filesList.innerHTML = uploadedFiles.map((file, index) => `
    <div class="file-item">
      <span class="file-name">${file.name}</span>
      <button class="file-remove" onclick="removeFile(${index})">✕</button>
    </div>
  `).join('');
}

// Tornar removeFile global
window.removeFile = removeFile;

async function extractAndFill() {
  try {
    extractBtn.disabled = true;
    showStatus('Extraindo informações dos PDFs...', 'info');
    
    const results = [];
    
    for (const file of uploadedFiles) {
      const data = await extractPDFData(file);
      results.push(data);
    }
    
    // Consolidar dados
    extractedData = {
      sraNumbers: results.map(r => r.sraNumber).filter(Boolean),
      issuingDate: results[0]?.issuingDate ? results[0].issuingDate.replace(/\//g, '-') : '',
      validUntil: results[0]?.validUntil ? results[0].validUntil.replace(/\//g, '-') : '',
      personName: results[0]?.personName || '',
      country: results[0]?.country || '',
      birthDate: results[0]?.birthDate || '',
      certificates: results.map(r => r.certificateNumber).filter(Boolean)
    };
    
    displayExtractedData();
    
    // Enviar para content script preencher o formulário
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    if (!tab.url.includes('forms.zoho.com')) {
      showStatus('Por favor, abra a página do Zoho Forms primeiro', 'error');
      extractBtn.disabled = false;
      return;
    }
    
    // Injetar e executar código diretamente na página
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: fillFormInPage,
        args: [extractedData]
      });
      
      showStatus('✓ Formulário preenchido! Validando dados...', 'info');
      
      // Validar dados após preencher
      setTimeout(async () => {
        await validateData(tab.id);
      }, 3000); // Aguarda 3 segundos para garantir que tudo foi preenchido
      
      uploadBtn.disabled = false;
    } catch (error) {
      console.error('Erro ao injetar script:', error);
      showStatus('Erro: ' + error.message, 'error');
    }
    
  } catch (error) {
    console.error('Erro ao extrair:', error);
    showStatus('Erro ao processar PDFs: ' + error.message, 'error');
  } finally {
    extractBtn.disabled = false;
  }
}

async function extractPDFData(file) {
  try {
    console.log('Iniciando extração do PDF:', file.name);
    
    const arrayBuffer = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
    
    console.log('PDF carregado, total de páginas:', pdf.numPages);
    
    let fullText = '';
    
    // Extrair texto de todas as páginas
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const textContent = await page.getTextContent();
      const pageText = textContent.items.map(item => item.str).join(' ');
      fullText += pageText + ' ';
    }
    
    console.log('Texto completo extraído (primeiros 800 chars):', fullText.substring(0, 800));
    
    // Extrair SRA Number (formato: PT2025OSRA007322701)
    const sraMatch = fullText.match(/PT\d{4}OSRA\d{9}/);
    const sraNumber = sraMatch ? sraMatch[0] : null;
    console.log('SRA Number encontrado:', sraNumber);
    
    // Extrair nome da pessoa (após "a to")
    let nameMatch = fullText.match(/a\s+to\s+([A-ZÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝ][a-zàáâãäåæçèéêëìíîïðñòóôõöøùúûüýÿąćęłńóśźż]+(?:\s+[A-ZÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝ][a-zàáâãäåæçèéêëìíîïðñòóôõöøùúûüýÿąćęłńóśźż]+)*?)\s+Nacionalidade/i);
    const personName = nameMatch ? nameMatch[1].trim() : null;
    console.log('Nome extraído:', personName);
    
    // Extrair país (após "Government of")
    const countryMatch = fullText.match(/Government of\s+([A-Z][a-zà-ÿ]+(?:\s+[A-Z][a-zà-ÿ]+)*)/i);
    const country = countryMatch ? countryMatch[1].trim() : null;
    console.log('País extraído:', country);
    
    // Extrair número do certificado (tudo entre "certificate no." e "emitido pelo")
    const certificateMatch = fullText.match(/certificate no\.\s+(.+?)\s+emitido pelo/i);
    const certificateNumber = certificateMatch ? certificateMatch[1].trim() : null;
    console.log('Certificado extraído:', certificateNumber);
    
    // Extrair data de nascimento
    const birthDateMatch = fullText.match(/Date of birth\s+(\d{4}\/\d{2}\/\d{2})/i);
    const birthDate = birthDateMatch ? birthDateMatch[1].replace(/\//g, '-') : null;
    console.log('Data de nascimento extraída:', birthDate);
    
    // Extrair todas as datas no formato YYYY/MM/DD
    const allDates = fullText.match(/\d{4}\/\d{2}\/\d{2}/g);
    console.log('Todas as datas encontradas:', allDates);
    
    let issuingDate = null;
    let validUntil = null;
    
    // Se encontrou datas, assumir que a primeira é emissão e segunda é validade
    if (allDates && allDates.length >= 2) {
      issuingDate = allDates[0];
      validUntil = allDates[1];
    }
    
    console.log('Data de emissão:', issuingDate);
    console.log('Validade:', validUntil);
    
    return {
      sraNumber,
      issuingDate,
      validUntil,
      personName,
      country,
      certificateNumber,
      birthDate
    };
  } catch (error) {
    console.error('ERRO ao extrair PDF:', error);
    throw error;
  }
}

function displayExtractedData() {
  extractedDataDiv.classList.remove('hidden');
  
  let html = '<strong>Dados Extraídos:</strong><br><br>';
  
  extractedData.sraNumbers.forEach((num, i) => {
    html += `<div class="data-row"><span class="data-label">SRA ${i + 1}:</span> ${num}</div>`;
  });
  
  html += `<div class="data-row"><span class="data-label">Data Emissão:</span> ${extractedData.issuingDate}</div>`;
  html += `<div class="data-row"><span class="data-label">Validade:</span> ${extractedData.validUntil}</div>`;
  
  if (extractedData.personName) {
    html += `<div class="data-row"><span class="data-label">Nome:</span> ${extractedData.personName}</div>`;
  }
  
  extractedDataDiv.innerHTML = html;
}

async function uploadToSharePoint() {
  try {
    console.log('uploadToSharePoint chamado!');
    
    const suffix = folderPathInput.value.trim();
    
    if (!suffix) {
      showStatus('Por favor, insira o sufixo da pasta (ex: NWO, EU)', 'error');
      return;
    }
    
    if (!extractedData.personName) {
      showStatus('Erro: Nome da pessoa não foi extraído do PDF', 'error');
      return;
    }
    
    // Obter o nome do navio diretamente da página do Zoho
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const iframes = document.querySelectorAll('iframe');
        for (let i = 0; i < iframes.length; i++) {
          try {
            const iframeDoc = iframes[i].contentDocument || iframes[i].contentWindow.document;
            const shipField = iframeDoc.querySelector('input[name="SingleLine"]');
            if (shipField && shipField.value) {
              return shipField.value.trim();
            }
          } catch (e) {
            // Ignorar erros de CORS
          }
        }
        return null;
      }
    });
    
    const shipName = results[0]?.result;
    console.log('Nome do navio obtido:', shipName);
    
    if (!shipName) {
      showStatus('Erro: Nome do navio não foi encontrado no formulário. Certifique-se de que o campo "Ship" está preenchido.', 'error');
      return;
    }
    
    // Montar o nome da pasta: "Nome Completo_SUFIXO"
    const folderName = `${extractedData.personName}_${suffix}`;
    console.log('Nome da pasta:', folderName);
    console.log('Nome do navio:', shipName);
    
    // Construir URL do SharePoint para a pasta
    const baseUrl = 'https://euregistry2.sharepoint.com/sites/EUROMAR-Seafarers';
    const folderPath = `/sites/EUROMAR-Seafarers/Shared Documents/Seafarers Documents/${shipName}/${folderName}`;
    const sharePointUrl = `${baseUrl}/Shared Documents/Forms/AllItems.aspx?id=${encodeURIComponent(folderPath)}&view=0`;
    
    console.log('Caminho da pasta:', folderPath);
    console.log('Abrindo URL:', sharePointUrl);
    
    // Abrir SharePoint numa nova aba
    chrome.tabs.create({ url: sharePointUrl });
    
    showStatus(`✓ Pasta aberta: ${shipName}/${folderName}`, 'success');
    
  } catch (error) {
    console.error('Erro:', error);
    showStatus('Erro: ' + error.message, 'error');
  }
}

function showStatus(message, type) {
  statusDiv.textContent = message;
  statusDiv.className = `status ${type}`;
  statusDiv.classList.remove('hidden');
  
  if (type === 'success' || type === 'error') {
    setTimeout(() => {
      statusDiv.classList.add('hidden');
    }, 5000);
  }
}

// Função para validar dados entre PDF e Zoho
async function validateData(tabId) {
  try {
    console.log('Iniciando validação...');
    
    // Ler dados do Zoho
    const results = await chrome.scripting.executeScript({
      target: { tabId: tabId },
      func: () => {
        const iframes = document.querySelectorAll('iframe');
        for (let i = 0; i < iframes.length; i++) {
          try {
            const iframeDoc = iframes[i].contentDocument || iframes[i].contentWindow.document;
            const testField = iframeDoc.querySelector('input[name="SingleLine12"]');
            
            if (testField) {
              // Extrair dados do Zoho
              const name = iframeDoc.querySelector('input[name="Name"]')?.value || '';
              const birthDate = iframeDoc.querySelector('input[name="Date"]')?.value || '';
              
              // Extrair país do dropdown
              const countryDropdown = iframeDoc.querySelector('#select2-Dropdown2-88-container');
              const country = countryDropdown?.textContent?.trim() || '';
              
              // Extrair certificados
              const coc = iframeDoc.querySelector('input[name="SingleLine4"]')?.value || '';
              const goc = iframeDoc.querySelector('input[name="SingleLine6"]')?.value || '';
              const cop1 = iframeDoc.querySelector('input[name="SingleLine8"]')?.value || '';
              const cop2 = iframeDoc.querySelector('input[name="SingleLine9"]')?.value || '';
              
              return {
                name,
                birthDate,
                country,
                certificates: [coc, goc, cop1, cop2].filter(c => c.length > 0)
              };
            }
          } catch (e) {
            // Ignorar
          }
        }
        return null;
      }
    });
    
    const zohoData = results[0]?.result;
    
    if (!zohoData) {
      showStatus('⚠️ Não foi possível ler dados do Zoho para validação', 'error');
      return;
    }
    
    console.log('Dados do Zoho:', zohoData);
    console.log('Dados dos PDFs:', extractedData);
    
    // Validar dados
    const errors = [];
    const warnings = [];
    
    // 1. Validar nome
    if (extractedData.personName && zohoData.name) {
      const namePDF = extractedData.personName.toLowerCase().trim();
      const nameZoho = zohoData.name.toLowerCase().trim();
      
      if (namePDF !== nameZoho) {
        // Verificar se é semelhante (tolerância)
        if (!nameZoho.includes(namePDF) && !namePDF.includes(nameZoho)) {
          errors.push(`Nome diferente! PDF: "${extractedData.personName}" vs Zoho: "${zohoData.name}"`);
        } else {
          warnings.push(`Nome ligeiramente diferente: PDF: "${extractedData.personName}" vs Zoho: "${zohoData.name}"`);
        }
      }
    }
    
    // 2. Validar data de nascimento
    if (extractedData.birthDate && zohoData.birthDate) {
      if (extractedData.birthDate !== zohoData.birthDate) {
        errors.push(`Data de nascimento diferente! PDF: "${extractedData.birthDate}" vs Zoho: "${zohoData.birthDate}"`);
      }
    }
    
    // 3. Validar país
    if (extractedData.country && zohoData.country) {
      const countryPDF = extractedData.country.toLowerCase();
      const countryZoho = zohoData.country.toLowerCase();
      
      if (countryPDF !== countryZoho) {
        errors.push(`País diferente! PDF: "${extractedData.country}" vs Zoho: "${zohoData.country}"`);
      }
    }
    
    // 4. Validar certificados
    if (extractedData.certificates.length > 0) {
      extractedData.certificates.forEach(cert => {
        if (!zohoData.certificates.includes(cert)) {
          errors.push(`Certificado "${cert}" não encontrado no Zoho!`);
        }
      });
    }
    
    // Mostrar resultado da validação
    if (errors.length > 0) {
      showStatus('❌ Erros encontrados: ' + errors.join(' | '), 'error');
      console.error('Erros de validação:', errors);
    } else if (warnings.length > 0) {
      showStatus('⚠️ Avisos: ' + warnings.join(' | '), 'info');
      console.warn('Avisos de validação:', warnings);
    } else {
      showStatus('✅ Tudo validado com sucesso!', 'success');
      console.log('✅ Validação completa - sem erros');
    }
    
  } catch (error) {
    console.error('Erro na validação:', error);
    showStatus('⚠️ Erro ao validar dados: ' + error.message, 'error');
  }
}

// Função que será injetada na página para preencher os campos
function fillFormInPage(data) {
  console.log('Preenchendo formulário com:', data);
  
  // Aguardar 2 segundos para garantir que tudo carregou
  setTimeout(() => {
    console.log('Iniciando preenchimento...');
    
    // Encontrar o iframe que contém os campos
    const iframes = document.querySelectorAll('iframe');
    let targetDoc = null;
    
    console.log('Procurando campos nos', iframes.length, 'iframes...');
    
    for (let i = 0; i < iframes.length; i++) {
      try {
        const iframeDoc = iframes[i].contentDocument || iframes[i].contentWindow.document;
        const testField = iframeDoc.querySelector('input[name="SingleLine12"]');
        if (testField) {
          console.log('✅ Campos encontrados no iframe', i);
          targetDoc = iframeDoc;
          break;
        }
      } catch (e) {
        // Iframe com restrições CORS, ignorar
      }
    }
    
    if (!targetDoc) {
      console.error('❌ Nenhum iframe com os campos foi encontrado!');
      alert('Erro: Não foi possível encontrar os campos do formulário. Por favor, recarregue a página e tente novamente.');
      return;
    }
    
    // Extrair o nome do navio do campo "SingleLine"
    const shipField = targetDoc.querySelector('input[name="SingleLine"]');
    const shipName = shipField ? shipField.value.trim() : '';
    console.log('Nome do navio extraído:', shipName);
    
    // Guardar o nome do navio para usar no SharePoint
    if (shipName) {
      window.postMessage({ type: 'SHIP_NAME_EXTRACTED', shipName: shipName }, '*');
    }
    
    // Obter setter nativo
    const nativeInputValueSetter = Object.getOwnPropertyDescriptor(
      window.HTMLInputElement.prototype, 
      "value"
    ).set;
    
    function fillField(fieldName, value) {
      if (!value) {
        console.log(`Valor vazio para ${fieldName}, pulando...`);
        return;
      }
      
      const field = targetDoc.querySelector(`input[name="${fieldName}"]`);
      if (!field) {
        console.log(`❌ Campo ${fieldName} não encontrado`);
        return;
      }
      
      try {
        field.focus();
        nativeInputValueSetter.call(field, value);
        field.dispatchEvent(new Event('input', { bubbles: true }));
        field.dispatchEvent(new Event('change', { bubbles: true }));
        field.dispatchEvent(new Event('blur', { bubbles: true }));
        field.blur();
        console.log(`✅ Preenchido ${fieldName} com ${value}`);
      } catch (error) {
        console.error(`❌ Erro ao preencher ${fieldName}:`, error);
      }
    }
    
    // Preencher SRA Numbers
    const sraFields = ['SingleLine12', 'SingleLine13', 'SingleLine14', 'SingleLine15'];
    console.log('SRA Numbers a preencher:', data.sraNumbers);
    
    data.sraNumbers.forEach((sraNumber, index) => {
      if (index < sraFields.length) {
        setTimeout(() => fillField(sraFields[index], sraNumber), index * 150);
      }
    });
    
    // Preencher datas
    setTimeout(() => {
      console.log('Preenchendo datas...');
      fillField('Date26', data.issuingDate);
    }, data.sraNumbers.length * 150 + 200);
    
    setTimeout(() => {
      fillField('Date27', data.validUntil);
    }, data.sraNumbers.length * 150 + 400);
    
    // Notificação de sucesso
    setTimeout(() => {
      const notification = document.createElement('div');
      notification.style.cssText = `
        position: fixed; top: 20px; right: 20px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white; padding: 16px 24px; border-radius: 8px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.3); z-index: 999999;
        font-family: -apple-system, sans-serif; font-size: 14px; font-weight: 600;
      `;
      notification.textContent = '✓ Formulário preenchido!';
      document.body.appendChild(notification);
      setTimeout(() => notification.remove(), 3000);
    }, data.sraNumbers.length * 150 + 800);
    
  }, 2000); // Aguarda 2 segundos após clicar no botão
}
