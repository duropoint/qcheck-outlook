// Background service worker para upload SharePoint

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'uploadToSharePoint') {
    handleSharePointUpload(request.files, request.folderPath)
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true; // Keep channel open for async response
  }
});

async function handleSharePointUpload(files, folderPath) {
  try {
    // URL base do SharePoint
    const siteUrl = 'https://euregistry2.sharepoint.com/sites/EUROMAR-Seafarers';
    const libraryName = 'Shared Documents';
    
    // Construir o caminho completo
    const fullPath = `${libraryName}/Seafarers Documents/${folderPath}`;
    
    // Para cada ficheiro, fazer upload
    for (const file of files) {
      const uploadUrl = `${siteUrl}/_api/web/GetFolderByServerRelativeUrl('${encodeURIComponent(fullPath)}')/Files/add(url='${encodeURIComponent(file.name)}',overwrite=true)`;
      
      // Obter token de autenticação (o utilizador já deve estar autenticado no SharePoint)
      const response = await fetch(uploadUrl, {
        method: 'POST',
        headers: {
          'Accept': 'application/json;odata=verbose',
          'Content-Type': 'application/octet-stream'
        },
        body: file.data,
        credentials: 'include' // Usar cookies de autenticação existentes
      });
      
      if (!response.ok) {
        // Se falhar, tentar criar a pasta primeiro
        await createFolder(siteUrl, fullPath);
        
        // Tentar upload novamente
        const retryResponse = await fetch(uploadUrl, {
          method: 'POST',
          headers: {
            'Accept': 'application/json;odata=verbose',
            'Content-Type': 'application/octet-stream'
          },
          body: file.data,
          credentials: 'include'
        });
        
        if (!retryResponse.ok) {
          throw new Error(`Falha ao fazer upload de ${file.name}: ${retryResponse.statusText}`);
        }
      }
    }
    
    return { success: true };
    
  } catch (error) {
    console.error('Erro no upload:', error);
    return { success: false, error: error.message };
  }
}

async function createFolder(siteUrl, folderPath) {
  // Dividir o caminho em partes e criar cada pasta recursivamente
  const parts = folderPath.split('/');
  let currentPath = '';
  
  for (const part of parts) {
    if (!part) continue;
    
    currentPath = currentPath ? `${currentPath}/${part}` : part;
    
    const createUrl = `${siteUrl}/_api/web/folders`;
    
    try {
      await fetch(createUrl, {
        method: 'POST',
        headers: {
          'Accept': 'application/json;odata=verbose',
          'Content-Type': 'application/json;odata=verbose'
        },
        body: JSON.stringify({
          '__metadata': { 'type': 'SP.Folder' },
          'ServerRelativeUrl': currentPath
        }),
        credentials: 'include'
      });
    } catch (e) {
      // Pasta pode já existir, continuar
      console.log(`Pasta ${currentPath} pode já existir`);
    }
  }
}

// Nota: A autenticação do SharePoint usa as credenciais já guardadas no browser
// O utilizador deve estar autenticado no SharePoint antes de usar esta funcionalidade