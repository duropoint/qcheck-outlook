console.log("🚀 BMAR Auto Complete - Content Script Loaded!");

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("📨 Mensagem recebida:", message.action);
  
  if (message.action === "ping") {
    sendResponse({ status: "pong" });
    return true;
  }
  
  if (message.action === "automate") {
    console.log("🎯 Starting full automation...");
    console.log("📦 message.options recebido:", message.options);
    console.log("🌍 message.options.medicalNationality:", message.options?.medicalNationality);
    executeFullAutomation(message.fields, message.documents, message.options || {});
    sendResponse({ status: "started" });
    return true;
  }
  
  if (message.action === "uploadOnly") {
    console.log("📤 Starting upload only (retry)...");
    sendProgress(75, "🔄 Tentando reenviar documentos...");
    uploadDocuments(message.documents);
    sendResponse({ status: "started" });
    return true;
  }
  
  return true;
});

async function executeFullAutomation(fields, documents, options) {
  try {
    sendProgress(5, "🔍 Verificando página atual...");
    
    const currentStep = detectCurrentStep();
    console.log("Current step:", currentStep);
    console.log("Additional options recebidas em executeFullAutomation:", options);
    console.log("Medical Nationality em executeFullAutomation:", options.medicalNationality);
    
    // 🔄 Redirecionar COC para Tankers se não houver certificado COC nos dados
    const hasCOCCertificate = fields["COC Number"] && fields["COC Number"].trim() !== "";
    
    console.log(`📋 Verificação COC: hasCOCCertificate=${hasCOCCertificate}, documents.coc=${!!documents.coc}`);
    
    if (!hasCOCCertificate && documents.coc) {
      console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
      console.log("⚠️  ATENÇÃO: Não há número COC nos dados do Zoho");
      console.log("📁 Mas existe ficheiro 04_coc_*");
      console.log("🔄 REDIRECIONANDO para Certificate of Proficiency (Tankers)");
      console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
      
      // Mover o documento COC para a categoria tanker
      documents.tankerCOC = documents.coc;
      delete documents.coc;
      console.log(`✅ Ficheiro "${documents.tankerCOC.name}" redirecionado para tankerCOC (Certificate of Proficiency)`);
    } else if (hasCOCCertificate && documents.coc) {
      console.log(`✅ COC Number encontrado: "${fields["COC Number"]}" - ficheiro vai para Certificate of Competency`);
    }

    if (currentStep === 2) {
      sendProgress(10, "📝 Preenchendo Step 2 (Applicant/Holder)...");
      await fillStep2(fields);
      await wait(1000);
      
      sendProgress(30, "➡️ Avançando para Step 3...");
      await clickNextButton();
      await wait(2000);
    }

    if (currentStep === 3 || currentStep === 2) {
      sendProgress(35, "📝 Preenchendo Step 3 (Characterization)...");
      await fillStep3(fields, options);
      await wait(1000);
      
      sendProgress(70, "➡️ Avançando para Step 4...");
      await clickNextButton();
      await wait(3000); // Espera para o Step 4 carregar
    }

    if (currentStep === 4 || currentStep === 3 || currentStep === 2) {
      sendProgress(75, "📤 Fazendo upload dos documentos...");
      await uploadDocuments(documents);
      sendProgress(100, "✅ Automação concluída!");
    }

    chrome.runtime.sendMessage({ type: "complete" });
    
  } catch (error) {
    console.error("❌ Erro na automação:", error);
    chrome.runtime.sendMessage({ 
      type: "error", 
      message: error.message 
    });
  }
}

function detectCurrentStep() {
  const steps = document.querySelectorAll('[class*="step"], [class*="Step"]');
  for (const step of steps) {
    if (step.textContent.includes("4") && step.className.includes("active")) return 4;
    if (step.textContent.includes("3") && step.className.includes("active")) return 3;
    if (step.textContent.includes("2") && step.className.includes("active")) return 2;
  }
  
  if (document.querySelector('label[id*="AnexoBean"]')) return 4;
  if (document.querySelector('button[id*="EndorsmentDetail"]')) return 3;
  if (document.querySelector('input[id*="PedidoPessoaTit"]')) return 2;
  
  return 2;
}

async function fillStep2(fields) {
  console.log("📝 Filling Step 2 (Page 1)...");
  
  const mappings = {
    "Birthdate": 'input[id="detailFormId:PedidoPessoaTit:PedidoPessoaTitBean_datNascimento_fld_input"]',
    "First Name": 'input[id="detailFormId:PedidoPessoaTit:PedidoPessoaTitBean_nomPessoa_fld"]',
    "Passport Number": 'input[id="detailFormId:PedidoPessoaTit:PedidoPessoaTitBean_numPassaporte_fld"]',
    "Passport Validity": 'input[id="detailFormId:PedidoPessoaTit:PedidoPessoaTitBean_datValidadePassap_fld_input"]'
  };
  
  const dropdownMappings = {
    "Sex": {
      select: 'select[id="detailFormId:PedidoPessoaTit:PedidoPessoaTitBean_codGenero_fld_input"]',
      label: 'label[id="detailFormId:PedidoPessoaTit:PedidoPessoaTitBean_codGenero_fld_label"]'
    },
    "Country of Origin": {
      select: 'select[id="detailFormId:PedidoPessoaTit:PedidoPessoaTitBean_xfkPaisNacionalid_fld_input"]',
      label: 'label[id="detailFormId:PedidoPessoaTit:PedidoPessoaTitBean_xfkPaisNacionalid_fld_label"]'
    },
    "Invoice": {
      select: 'select[id="detailFormId:PedidoRequerenteBean_codDestFatura_fld_input"]',
      label: 'label[id="detailFormId:PedidoRequerenteBean_codDestFatura_fld_label"]'
    }
  };
  
  for (const [key, selector] of Object.entries(mappings)) {
    if (fields[key]) {
      pasteInput(selector, fields[key]);
      await wait(200);
    }
  }
  
  for (const [key, selectors] of Object.entries(dropdownMappings)) {
    if (fields[key] && fields[key] !== "-Select-") {
      pasteDropdown(selectors.select, selectors.label, fields[key]);
      await wait(200);
    }
  }
  
  console.log("✅ Step 2 completed");
}

async function fillStep3(fields, options = {}) {
  console.log("📝 Filling Step 3 (Characterization)...");
  console.log("📊 Campos disponíveis:", fields);
  console.log("⚙️ Opções adicionais:", options);
  console.log("🔍 options.medicalNationality em fillStep3:", options.medicalNationality);
  
  console.log("⏩ Chamando fillMedicalInfo com options:", options);
  await fillMedicalInfo(fields, options);
  await wait(500);
  
  const hasCOC = fields["COC Number"] && fields["COC Number"].trim() !== "";
  const hasGOC = fields["GOC Number"] && fields["GOC Number"].trim() !== "";
  const hasCOP1 = fields["COP1 Number"] && fields["COP1 Number"].trim() !== "";
  const hasCOP2 = fields["COP2 Number"] && fields["COP2 Number"].trim() !== "";
  
  console.log(`📋 Certificados detectados:
    COC: ${hasCOC ? '✅ ' + fields["COC Number"] : '❌'}
    GOC: ${hasGOC ? '✅ ' + fields["GOC Number"] : '❌'}
    COP1: ${hasCOP1 ? '✅ ' + fields["COP1 Number"] : '❌'}
    COP2: ${hasCOP2 ? '✅ ' + fields["COP2 Number"] : '❌'}
  `);
  
  if (hasCOC) {
    console.log("➡️ Adicionando COC com Rules...");
    await addCertificateWithRules("STCW", fields, "COC", options);
    await wait(1000);
  }
  
  if (hasGOC) {
    console.log("➡️ Adicionando GOC com Rules...");
    await addCertificateWithRules("STCW (GMDSS)", fields, "GOC", options);
    await wait(1000);
  }
  
  if (hasCOP1) {
    console.log("➡️ Adicionando COP1 com Rules...");
    await addCertificateWithRules("STCW (Tankers)", fields, "COP1", options);
    await wait(1000);
  }
  
  if (hasCOP2) {
    console.log("➡️ Adicionando COP2 com Rules...");
    await addCertificateWithRules("STCW (Tankers)", fields, "COP2", options);
    await wait(1000);
  }
  
  console.log("✅ Step 3 completed");
}

async function fillMedicalInfo(fields, options = {}) {
  console.log("📋 Filling Medical Info (Page 2)...");
  console.log("🌍 Medical Nationality recebida:", options.medicalNationality);
  
  // Ordem correta: Issuance -> Expiry -> Issuing Place
  
  // 1. Medical Issuance date
  if (fields["Medical Issuance date"]) {
    console.log("📅 Preenchendo Medical Issuance date...");
    pasteInput('input[id="detailFormId:EndorsmentDetail:EndorsmentBean_datEmissaoDm_fld_input"]', fields["Medical Issuance date"]);
    await wait(500);
  }
  
  // 2. Medical Expiry
  if (fields["Medical Expiry"]) {
    console.log("📅 Preenchendo Medical Expiry...");
    pasteInput('input[id="detailFormId:EndorsmentDetail:EndorsmentBean_datValidadeDm_fld_input"]', fields["Medical Expiry"]);
    await wait(500);
  }
  
  // 3. Issuing Place (nacionalidade do Medical Certificate)
  if (options.medicalNationality && options.medicalNationality.trim() !== "") {
    console.log(`🌍 Preenchendo "Issuing Place" com: "${options.medicalNationality}"`);
    const input = document.querySelector('input[id="detailFormId:EndorsmentDetail:EndorsmentBean_txtLocEmissaoDm_fld"]');
    
    if (input) {
      console.log("✅ Campo 'Issuing Place' encontrado!");
      input.focus();
      input.value = options.medicalNationality;
      input.dispatchEvent(new Event("input", { bubbles: true }));
      input.dispatchEvent(new Event("change", { bubbles: true }));
      input.dispatchEvent(new Event("blur", { bubbles: true }));
      console.log(`✅ "Issuing Place" preenchido com: "${input.value}"`);
    } else {
      console.error("❌ Campo 'Issuing Place' NÃO encontrado!");
    }
    await wait(500);
  } else {
    console.warn(`⚠️ Medical Nationality não fornecida - "Issuing Place" não será preenchido`);
  }
  
  // 4. Ship (se existir)
  if (fields["Ship"]) {
    console.log("🚢 Preenchendo Ship...");
    pasteInput('input[id="detailFormId:EndorsmentDetail:EndorsmentBean_txtLocEmiDeclar_fld"]', fields["Ship"]);
    await wait(300);
  }
  
  // Selecionar automaticamente "Digital Document"
  console.log("📄 Selecionando 'Digital Document' automaticamente...");
  const digitalDocSelect = document.querySelector('select[id="detailFormId:EndorsmentDetail:EndorsmentBean_flgDocFisico_fld_input"]');
  const digitalDocLabel = document.querySelector('label[id="detailFormId:EndorsmentDetail:EndorsmentBean_flgDocFisico_fld_label"]');
  
  if (digitalDocSelect) {
    const option = Array.from(digitalDocSelect.options).find(opt => 
      opt.value === "NAO"
    );
    
    if (option) {
      console.log(`✅ Selecionando "Digital Document" (value: NAO)`);
      digitalDocSelect.value = option.value;
      digitalDocSelect.dispatchEvent(new Event("change", { bubbles: true }));
      
      if (digitalDocLabel) {
        digitalDocLabel.textContent = "Digital Document";
      }
      
      await wait(300);
      console.log(`✅ "Digital Document" selecionado com sucesso!`);
    } else {
      console.warn(`⚠️ Opção com value "NAO" não encontrada`);
    }
  } else {
    console.warn(`⚠️ Dropdown de formato físico não encontrado`);
  }
}

async function addCertificateWithRules(certType, fields, prefix, options) {
  await addCertificateOnly(certType, fields, prefix);
  
  // 🔍 DEBUG das options
  console.log(`\n🔍 DEBUG - addCertificateWithRules para ${prefix}:`);
  console.log(`   certType: ${certType}`);
  console.log(`   prefix: ${prefix}`);
  console.log(`   options:`, options);
  console.log(`   options.addRuleCapacity: ${options.addRuleCapacity}`);
  console.log(`   options.stcwRule: ${options.stcwRule}`);
  console.log(`   options.capacity: ${options.capacity}`);
  console.log(`   options.addTankerCapacity: ${options.addTankerCapacity}`);
  console.log(`   options.cop1Rule: ${options.cop1Rule}`);
  console.log(`   options.cop2Rule: ${options.cop2Rule}`);
  console.log(`   options.tankerCapacity: ${options.tankerCapacity}`);
  
  let shouldAddRule = false;
  let ruleToAdd = null;
  let capacityToAdd = null;
  
  if (prefix === "COC" && options.addRuleCapacity && options.stcwRule && options.capacity) {
    console.log(`✅ COC: Condições satisfeitas para adicionar Rule`);
    shouldAddRule = true;
    ruleToAdd = options.stcwRule;
    capacityToAdd = options.capacity;
  } else if (prefix === "COC") {
    console.log(`❌ COC: Condições NÃO satisfeitas para adicionar Rule`);
    console.log(`   addRuleCapacity=${options.addRuleCapacity}, stcwRule=${options.stcwRule}, capacity=${options.capacity}`);
  }
  
  if (prefix === "GOC") {
    console.log(`✅ GOC: Sempre adiciona Rule IV/2`);
    shouldAddRule = true;
    ruleToAdd = "IV/2";
    capacityToAdd = "GMDSS Radio Operator";
  }
  
  if (prefix === "COP1" && options.addTankerCapacity && options.cop1Rule && options.tankerCapacity) {
    console.log(`✅ COP1: Condições satisfeitas para adicionar Rule`);
    shouldAddRule = true;
    ruleToAdd = options.cop1Rule;
    capacityToAdd = options.tankerCapacity;
    console.log(`📋 COP1 vai adicionar Rule: ${ruleToAdd}`);
  } else if (prefix === "COP1") {
    console.log(`❌ COP1: Condições NÃO satisfeitas para adicionar Rule`);
    console.log(`   addTankerCapacity=${options.addTankerCapacity}, cop1Rule=${options.cop1Rule}, tankerCapacity=${options.tankerCapacity}`);
  }
  
  if (prefix === "COP2" && options.addTankerCapacity && options.cop2Rule && options.tankerCapacity) {
    console.log(`✅ COP2: Condições satisfeitas para adicionar Rule`);
    shouldAddRule = true;
    ruleToAdd = options.cop2Rule;
    capacityToAdd = options.tankerCapacity;
    console.log(`📋 COP2 vai adicionar Rule: ${ruleToAdd}`);
  } else if (prefix === "COP2") {
    console.log(`❌ COP2: Condições NÃO satisfeitas para adicionar Rule`);
    console.log(`   addTankerCapacity=${options.addTankerCapacity}, cop2Rule=${options.cop2Rule}, tankerCapacity=${options.tankerCapacity}`);
  }
  
  if (shouldAddRule) {
    console.log(`📋 Adicionando Rule DENTRO do modal do certificado...`);
    console.log(`   Rule: ${ruleToAdd}, Capacity: ${capacityToAdd}`);
    await addRuleInsideModal(ruleToAdd, capacityToAdd, prefix);
  }
  
  console.log(`💾 Procurando botão Confirm do certificado...`);
  await wait(500);
  
  const confirmBtn = Array.from(document.querySelectorAll("button")).find(b => 
    (b.innerText.includes("Confirm") || b.innerText.includes("Confirmar")) &&
    b.id.includes("detailFormId") &&
    !b.id.includes("EndorsCertifRegra")
  );
  
  if (confirmBtn) {
    console.log(`✅ Botão Confirm encontrado: ${confirmBtn.id}`);
    confirmBtn.click();
    await wait(3000); // Aumentar espera para garantir que o modal fecha completamente
    console.log(`✅ Certificate ${prefix} saved`);
  } else {
    console.error(`❌ Botão Confirm do certificado não encontrado`);
  }
}

async function addCertificateOnly(certType, fields, prefix) {
  console.log(`📜 Adding certificate: ${prefix} (${certType})...`);
  sendProgress(40 + (prefix === "COC" ? 0 : prefix === "GOC" ? 10 : prefix === "COP1" ? 20 : 30), 
               `📜 Adicionando ${prefix}...`);
  
  const addButton = Array.from(document.querySelectorAll('button')).find(btn => 
    btn.id.includes("EndorsmentDetail") && 
    (btn.innerText.includes("Add New") || btn.innerText.includes("Adicionar"))
  );
  
  if (addButton) {
    console.log(`✅ Found Add New button: ${addButton.id}`);
    addButton.click();
    await wait(2000);
  } else {
    console.error("❌ Add New button not found");
    return;
  }
  
  console.log(`🔍 Procurando dropdown de tipo de certificado...`);
  const typeDropdown = document.querySelector('select[id*="xfkTpCertif_fld_input"]');
  const typeLabel = document.querySelector('label[id*="xfkTpCertif_fld_label"]');
  
  if (typeDropdown) {
    console.log(`✅ Dropdown encontrado. Opções disponíveis:`);
    Array.from(typeDropdown.options).forEach(opt => {
      console.log(`   - "${opt.text}" (value: ${opt.value})`);
    });
    
    const option = Array.from(typeDropdown.options).find(opt => {
      const optText = opt.text.trim();
      if (certType === "STCW" && optText === "STCW") return true;
      if (certType === "STCW (GMDSS)" && (optText.includes("GMDSS") || optText.includes("Radiocommunications"))) return true;
      if (certType === "STCW (Tankers)" && optText.includes("Tanker")) return true;
      return optText.includes(certType);
    });
    
    if (option) {
      console.log(`✅ Selecionando opção: "${option.text}"`);
      typeDropdown.value = option.value;
      typeDropdown.dispatchEvent(new Event("change", { bubbles: true }));
      
      if (typeLabel) {
        typeLabel.textContent = option.text;
      }
      
      await wait(1000);
      console.log(`✅ Selected certificate type: ${option.text}`);
    } else {
      console.error(`❌ Opção "${certType}" não encontrada no dropdown`);
    }
  } else {
    console.error("❌ Dropdown de tipo de certificado não encontrado");
  }
  
  console.log(`🔍 Preenchendo campos do certificado ${prefix}...`);
  const certMappings = {
    [`${prefix} Number`]: 'input[id="detailFormId:EndorsmentCertifBean_numCertificado_fld"]',
    [`${prefix} Issuance`]: 'input[id="detailFormId:EndorsmentCertifBean_datEmissaoCert_fld_input"]',
    [`${prefix} Expiry`]: 'input[id="detailFormId:EndorsmentCertifBean_datValidadeCert_fld_input"]',
    [`${prefix} Endorsement Number`]: 'input[id="detailFormId:EndorsmentCertifBean_numEndorsment_fld"]',
    [`${prefix} Endorsement Issuance`]: 'input[id="detailFormId:EndorsmentCertifBean_datEmissaoEndors_fld_input"]',
    [`${prefix} Endorsement Expiry`]: 'input[id="detailFormId:EndorsmentCertifBean_datValidadeEndors_fld_input"]',
    [`${prefix} Revalidation date`]: 'input[id="detailFormId:EndorsmentCertifBean_datRevalidCert_fld_input"]',
    [`${prefix} Revalidation Expiry date`]: 'input[id="detailFormId:EndorsmentCertifBean_datValRevalCert_fld_input"]'
  };
  
  for (const [key, selector] of Object.entries(certMappings)) {
    if (fields[key]) {
      console.log(`   ✏️ ${key}: ${fields[key]}`);
      pasteInput(selector, fields[key]);
      await wait(300);
    }
  }
  
  const issuedByKey = `${prefix} Issued By`;
  if (fields[issuedByKey]) {
    console.log(`   🌍 ${issuedByKey}: ${fields[issuedByKey]}`);
    pasteDropdown(
      'select[id="detailFormId:EndorsmentCertifBean_xfkPaisEmiCert_fld_input"]',
      'label[id="detailFormId:EndorsmentCertifBean_xfkPaisEmiCert_fld_label"]',
      fields[issuedByKey]
    );
    await wait(300);
  }
  
  const endorsementIssuedByKey = `${prefix} Endorsement Issued By`;
  if (fields[endorsementIssuedByKey]) {
    console.log(`   🌍 ${endorsementIssuedByKey}: ${fields[endorsementIssuedByKey]}`);
    pasteDropdown(
      'select[id="detailFormId:EndorsmentCertifBean_xfkPaisEmiEndors_fld_input"]',
      'label[id="detailFormId:EndorsmentCertifBean_xfkPaisEmiEndors_fld_label"]',
      fields[endorsementIssuedByKey]
    );
    await wait(300);
  }
}

async function addRuleInsideModal(stcwRule, capacity, certType) {
  console.log(`📋 Adding Rule INSIDE modal: ${stcwRule}, Capacity: ${capacity}`);
  
  try {
    console.log(`🔍 Procurando secção "Certificate's Rules and Capacities"...`);
    await wait(2000);
    
    // Fazer scroll no modal para garantir que a secção está visível
    const modal = document.querySelector('.ui-dialog[aria-hidden="false"]');
    if (modal) {
      const modalContent = modal.querySelector('.ui-dialog-content');
      if (modalContent) {
        modalContent.scrollTop = modalContent.scrollHeight;
        console.log(`✅ Scroll feito no modal`);
        await wait(1000);
      }
    }
    
    // Procurar especificamente pela secção "Certificate's Rules and Capacities"
    const rulesSection = Array.from(document.querySelectorAll('.ui-fieldset-legend, legend, .ui-panel-title'))
      .find(el => {
        const text = el.textContent.trim().toLowerCase();
        return text.includes("certificate's rules") || 
               text.includes("rules and capacities") ||
               text.includes("stcw rule");
      });
    
    if (rulesSection) {
      console.log(`✅ Secção encontrada: "${rulesSection.textContent.trim()}"`);
    } else {
      console.warn(`⚠️ Secção "Certificate's Rules and Capacities" não encontrada`);
    }
    
    // Procurar o botão "Add New" dentro dessa secção ou próximo dela
    let addRuleBtn = null;
    
    if (rulesSection) {
      // Procurar no mesmo container (fieldset ou panel)
      const container = rulesSection.closest('fieldset, .ui-panel, .ui-fieldset');
      if (container) {
        console.log(`✅ Container da secção encontrado`);
        addRuleBtn = container.querySelector('button');
        if (addRuleBtn && addRuleBtn.innerText.includes("Add New")) {
          console.log(`✅ Botão "Add New" encontrado dentro da secção: ${addRuleBtn.id}`);
        }
      }
    }
    
    // Fallback: procurar por um fieldset que contenha "Add New" e esteja visível
    if (!addRuleBtn) {
      console.log(`🔍 Fallback: procurando fieldset com botão Add New...`);
      const allFieldsets = Array.from(document.querySelectorAll('fieldset'));
      for (const fieldset of allFieldsets) {
        const legend = fieldset.querySelector('legend');
        if (legend && legend.textContent.toLowerCase().includes('rule')) {
          const btn = fieldset.querySelector('button');
          if (btn && btn.innerText.includes("Add New") && btn.offsetParent !== null) {
            addRuleBtn = btn;
            console.log(`✅ Botão encontrado via fieldset: ${btn.id}`);
            break;
          }
        }
      }
    }
    
    if (!addRuleBtn) {
      console.warn(`⚠️ Botão "Add New" das Rules não encontrado`);
      console.warn(`   A secção existe mas o botão pode estar oculto ou inacessível`);
      return;
    }
    
    console.log(`✅ Clicando no botão das Rules: ${addRuleBtn.id}`);
    addRuleBtn.click();
    await wait(2000);
    
    await addRuleAndCapacity(stcwRule, capacity, certType);
    
  } catch (error) {
    console.error(`❌ Erro ao adicionar Rule:`, error);
  }
}

async function addRuleAndCapacity(stcwRule, capacity, certType) {
  console.log(`📋 Adding STCW Rule: ${stcwRule}, Capacity: ${capacity}, Type: ${certType}`);
  
  try {
    console.log(`🔍 Procurando dropdowns de Rule e Capacity...`);
    await wait(1000);
    
    const ruleTextMap = {
      "II/1": "Rule II/1 - Officer in charge of a navigational watch on ships of 500 GT or more",
      "II/2": "Rule II/2 - Master and Chief Mate on ships of 500 GT or more",
      "II/3": "Rule II/3 - Officer in charge of a navigational watch on ships of less than 500 GT, engaged on near coastal voyages",
      "III/1": "Rule III/1 - Officer in Charge of an Engineering Watch",
      "III/2": "Rule III/2 - Chief Engineer Officer and Second Engineer Officer on ships powered by main propulsion machinery of 3000 KW propulsion power or more",
      "III/3": "Rule III/3 - Chief Engineer Officer and Second Engineer Officeron ships powered by main propulsion machinery of between 750 KW and 3000 KW propulsion power)",
      "III/6": "Rule III/6 - Electrotechnical Officer",
      "IV/2": "Rule IV/2 - GMDSS Radio Operator",
      "V/1-1-1": "Rule V/1-1-1 - Basic training for oil and chemical tanker cargo operations",
      "V/1-1-2": "Rule V/1-1-2 - Advanced training for oil tanker cargo operations",
      "V/1-1-3": "Rule V/1-1-3 - Advanced training for chemical tanker cargo operations",
      "V/1-2-1": "Rule V/1-2-1 - Basic training for liquified gas tanker cargo operations",
      "V/1-2-2": "Rule V/1-2-2 - Advanced training for liquified gas tanker cargo operations"
    };
    
    const ruleFullText = ruleTextMap[stcwRule];
    
    console.log(`🔍 Procurando dropdown de STCW Rule...`);
    const ruleSelect = document.querySelector('select[id*="xfkRegraStcw_fld_input"]');
    const ruleLabel = document.querySelector('label[id*="xfkRegraStcw_fld_label"]');
    
    if (ruleSelect && ruleFullText) {
      console.log(`✅ Dropdown de Rule encontrado: ${ruleSelect.id}`);
      console.log(`📊 Opções disponíveis no dropdown:`);
      Array.from(ruleSelect.options).forEach(opt => {
        console.log(`   - "${opt.text}"`);
      });
      
      console.log(`🔍 Procurando por: "${ruleFullText}" ou "${stcwRule}"`);
      
      const option = Array.from(ruleSelect.options).find(opt => 
        opt.text.includes(ruleFullText) || opt.text.includes(stcwRule) || 
        (stcwRule.startsWith("V/1") && opt.text.includes(stcwRule))
      );
      
      if (option) {
        console.log(`✅ Selecionando Rule: ${option.text}`);
        ruleSelect.value = option.value;
        ruleSelect.dispatchEvent(new Event("change", { bubbles: true }));
        
        if (ruleLabel) {
          ruleLabel.textContent = option.text;
        }
        
        await wait(1000);
        console.log(`✅ Rule selecionada com sucesso!`);
      } else {
        console.warn(`⚠️ Rule ${stcwRule} não encontrada no dropdown`);
        console.log(`💡 Texto procurado: "${ruleFullText}"`);
        console.log(`❌ PROBLEMA: As rules dos Tankers (V/1-X) não aparecem neste dropdown!`);
        console.log(`   Isto significa que o tipo de certificado pode não ser "STCW (Tankers)"`);
        return;
      }
    } else {
      console.error(`❌ Dropdown de Rule não encontrado`);
      return;
    }
    
    console.log(`🔍 Procurando dropdown de Capacity...`);
    const capacitySelect = document.querySelector('select[id*="xfkCargoStcw_fld_input"]');
    const capacityLabel = document.querySelector('label[id*="xfkCargoStcw_fld_label"]');
    
    if (capacitySelect && capacity) {
      console.log(`✅ Dropdown de Capacity encontrado: ${capacitySelect.id}`);
      console.log(`📊 Opções disponíveis:`);
      Array.from(capacitySelect.options).forEach(opt => {
        console.log(`   - "${opt.text}"`);
      });
      
      const option = Array.from(capacitySelect.options).find(opt => 
        opt.text.trim() === capacity || opt.text.includes(capacity)
      );
      
      if (option) {
        console.log(`✅ Selecionando Capacity: ${option.text}`);
        capacitySelect.value = option.value;
        capacitySelect.dispatchEvent(new Event("change", { bubbles: true }));
        
        if (capacityLabel) {
          capacityLabel.textContent = option.text;
        }
        
        await wait(500);
      } else {
        console.warn(`⚠️ Capacity ${capacity} não encontrada no dropdown`);
        return;
      }
    } else {
      console.error(`❌ Dropdown de Capacity não encontrado`);
      return;
    }
    
    await wait(500);
    console.log(`💾 Procurando botão Confirm das Rules...`);
    const confirmRuleBtn = Array.from(document.querySelectorAll("button")).find(b => 
      (b.innerText.includes("Confirm") || b.innerText.includes("Confirmar")) &&
      b.id.match(/j_idt\d{5}/) &&
      b.offsetParent !== null
    );
    
    if (confirmRuleBtn) {
      console.log(`✅ Confirmando Rule & Capacity: ${confirmRuleBtn.id}`);
      confirmRuleBtn.click();
      await wait(1500);
      console.log(`✅ Rule & Capacity adicionados com sucesso!`);
    } else {
      console.error(`❌ Botão Confirm das Rules não encontrado`);
      console.log(`Botões Confirm visíveis:`);
      Array.from(document.querySelectorAll("button")).filter(b => 
        b.offsetParent !== null && 
        (b.innerText.includes("Confirm") || b.innerText.includes("Confirmar"))
      ).forEach(b => console.log(`   - "${b.innerText}" (ID: ${b.id})`));
    }
    
  } catch (error) {
    console.error(`❌ Erro ao adicionar Rule & Capacity:`, error);
  }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 📤 FUNÇÃO DE UPLOAD - VERSÃO CORRIGIDA
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

async function uploadDocuments(documents) {
  console.log("📤 Starting document upload...");
  await wait(2000); // Espera para página carregar
  
  // Mapeamento de tipos para labels EXATOS da página
  const textos = {
    seamans: "Seaman's Book",
    coc: "Certificate of Competency",
    gmdss: "Radiocommunications Certificate",
    med: "Medical Certificate",
    rok: "Statement",
    tanker: "Certificate of Proficiency",
    tankerChem: "Certificate of Proficiency",
    tankerOil: "Certificate of Proficiency",
    tankerCOC: "Certificate of Proficiency",
    pass: "Passport or Other Seafarer Identity Document",
    loc: "Other document"
  };
  
  let uploadCount = 0;
  const totalDocs = Object.keys(documents).filter(k => documents[k]).length;
  
  // 📊 Tracking de sucessos e falhas
  const uploadResults = {
    success: [],
    failed: []
  };
  
  for (const [tipo, ficheiro] of Object.entries(documents)) {
    if (!ficheiro) continue;
    
    uploadCount++;
    console.log(`\n📄 [${uploadCount}/${totalDocs}] Uploading: ${ficheiro.name}`);
    
    sendProgress(75 + (uploadCount * Math.floor(20 / totalDocs)), `📤 Upload ${uploadCount}/${totalDocs}: ${ficheiro.name}`);
    
    try {
      const success = await uploadSingleDocument(tipo, ficheiro, textos[tipo]);
      
      if (success) {
        uploadResults.success.push({ name: ficheiro.name, type: tipo });
        console.log(`✅ ${ficheiro.name} uploaded!`);
      } else {
        uploadResults.failed.push({ name: ficheiro.name, type: tipo, reason: "Upload falhou" });
        console.error(`❌ ${ficheiro.name} falhou`);
      }
      
    } catch (error) {
      console.error(`❌ Erro: ${ficheiro.name} - ${error.message}`);
      uploadResults.failed.push({ name: ficheiro.name, type: tipo, reason: error.message });
    }
    
    await wait(500); // Pausa breve entre uploads
  }
  
  // 📊 Resumo final
  console.log(`\n📊 RESUMO: ✅ ${uploadResults.success.length} | ❌ ${uploadResults.failed.length}`);
  
  // Enviar resultado final para o popup
  chrome.runtime.sendMessage({ 
    type: "uploadComplete", 
    results: uploadResults 
  });
}

// Nova função para upload de um único documento
async function uploadSingleDocument(tipo, ficheiro, labelText) {
  // Procurar pelo label e navegar até o botão
  let addBtn = null;
  console.log(`🔍 Procurando label: "${labelText}"`);
  
  const label = Array.from(document.querySelectorAll("label.ui-outputlabel"))
    .find(l => l.textContent.trim() === labelText);
  
  if (label) {
    console.log(`✅ Label encontrado: "${label.textContent.trim()}"`);
    
    // Navegar até o panel-content
    let panelContent = label.closest(".ui-panel-content");
    
    if (panelContent) {
      console.log(`✅ Panel content encontrado`);
      
      // Procurar o botão "Add New" dentro deste panel
      const buttons = Array.from(panelContent.querySelectorAll("button"));
      addBtn = buttons.find(b => b.innerText.trim() === "Add New");
      
      if (addBtn) {
        console.log(`✅ Botão "Add New" encontrado no panel: ${addBtn.id}`);
      } else {
        console.error(`❌ Botão "Add New" não encontrado no panel`);
      }
    } else {
      console.error(`❌ Panel content não encontrado`);
    }
  } else {
    console.error(`❌ Label "${labelText}" não encontrado`);
  }
  
  if (!addBtn) {
    console.error(`❌ Botão 'Add New' não encontrado para ${tipo}`);
    throw new Error("Botão Add New não encontrado");
  }
  
  // Clicar no botão
  console.log(`🖱️ A clicar no botão: ${addBtn.id}`);
  addBtn.click();
  
  // Esperar pelo modal de upload
  console.log(`⏳ Aguardando modal de upload...`);
  await wait(2000);
  
  // Procurar o input de ficheiro
  let fileInput = null;
  let attempts = 0;
  const maxAttempts = 15;
  
  while (!fileInput && attempts < maxAttempts) {
    attempts++;
    console.log(`🔍 Tentativa ${attempts}/${maxAttempts} para encontrar file input...`);
    
    // Procurar input de ficheiro visível
    const allFileInputs = document.querySelectorAll('input[type="file"]');
    const visibleInputs = Array.from(allFileInputs).filter(inp => {
      const style = window.getComputedStyle(inp);
      return style.display !== 'none' && style.visibility !== 'hidden';
    });
    
    if (visibleInputs.length > 0) {
      fileInput = visibleInputs[0];
      console.log(`✅ File input encontrado: ${fileInput.id || fileInput.name}`);
      break;
    }
    
    // Tentar pelo ID específico
    const specificInput = document.getElementById("detailFormId:AnexoBean_binFicheiro_fld_input");
    if (specificInput) {
      fileInput = specificInput;
      console.log(`✅ File input encontrado pelo ID específico`);
      break;
    }
    
    if (!fileInput) {
      await wait(500);
    }
  }
  
  if (!fileInput) {
    console.error(`❌ Input de ficheiro não encontrado após ${maxAttempts} tentativas`);
    throw new Error("Input de ficheiro não encontrado");
  }
  
  // Converter base64 para Blob
  console.log(`🔄 A converter base64 para blob...`);
  const blob = b64toBlob(ficheiro.data, "application/pdf");
  console.log(`✅ Blob criado: ${(blob.size / 1024).toFixed(2)} KB`);
  
  // Verificar tamanho (limite comum: 10MB)
  const maxSizeKB = 10 * 1024; // 10MB em KB
  if (blob.size / 1024 > maxSizeKB) {
    console.warn(`⚠️ AVISO: Ficheiro muito grande: ${(blob.size / 1024).toFixed(2)} KB (máx: ${maxSizeKB} KB)`);
  }
  
  // Criar File object
  const file = new File([blob], ficheiro.name, { type: "application/pdf" });
  console.log(`✅ File object criado: ${file.name} (${(file.size / 1024).toFixed(2)} KB)`);
  
  // Atribuir ao input
  const dt = new DataTransfer();
  dt.items.add(file);
  fileInput.files = dt.files;
  console.log(`✅ Ficheiro atribuído ao input`);
  
  // Disparar eventos
  fileInput.dispatchEvent(new Event("change", { bubbles: true }));
  fileInput.dispatchEvent(new Event("input", { bubbles: true }));
  console.log(`✅ Eventos disparados`);
  
  await wait(1500);
  
  // Verificar se há mensagem de erro
  const errorMessages = Array.from(document.querySelectorAll('.ui-message-error, .ui-messages-error, .ui-messages-error-detail'));
  const hasError = errorMessages.some(e => e.textContent.trim());
  
  if (hasError) {
    const errorText = errorMessages.map(e => e.textContent.trim()).filter(t => t).join('; ');
    console.warn(`⚠️ AVISO de erro na página: ${errorText || '(erro vazio)'}`);
    
    // NÃO fechar o modal - vamos tentar continuar
    // O erro pode ser apenas um aviso que podemos ignorar
    console.log(`⚠️ Vou tentar continuar apesar do erro...`);
  }
  
  // Procurar botão Confirm (mesmo que haja erro)
  console.log(`🔍 A procurar botão Confirm...`);
  
  let confirmBtn = null;
  const allButtons = Array.from(document.querySelectorAll("button"));
  const visibleButtons = allButtons.filter(b => b.offsetParent !== null);
  
  confirmBtn = visibleButtons.find(b => {
    const text = b.innerText.trim();
    return text === "Confirm" || text === "Confirmar" || 
           text.includes("Confirm") || text.includes("Confirmar");
  });
  
  if (!confirmBtn) {
    console.error(`❌ Botão Confirm não encontrado`);
    
    // Se há erro E não há botão Confirm, então precisamos fechar e desistir
    if (hasError) {
      console.log(`🔍 Procurando botão Cancel para fechar...`);
      const cancelBtn = visibleButtons.find(b => 
        b.innerText.includes('Cancel') || b.innerText.includes('Cancelar')
      );
      
      if (cancelBtn) {
        console.log(`✅ Fechando modal com Cancel`);
        cancelBtn.click();
        await wait(1000);
      }
      
      throw new Error(errorMessages.map(e => e.textContent.trim()).filter(t => t).join('; ') || "Erro ao fazer upload");
    }
    
    throw new Error("Botão Confirm não encontrado");
  }
  
  console.log(`✅ Botão Confirm encontrado: "${confirmBtn.innerText}" (${confirmBtn.id})`);
  console.log(`🖱️ A clicar em Confirm...`);
  confirmBtn.click();
  await wait(2000);
  
  // Verificar se o erro persiste após Confirm
  if (hasError) {
    // Verificar se ainda há mensagens de erro após clicar
    await wait(500);
    const postConfirmErrors = Array.from(document.querySelectorAll('.ui-message-error, .ui-messages-error'));
    if (postConfirmErrors.length > 0) {
      const errorText = postConfirmErrors.map(e => e.textContent.trim()).filter(t => t).join('; ');
      if (errorText) {
        console.error(`❌ Erro persistiu após Confirm: ${errorText}`);
        throw new Error(errorText);
      }
    }
  }
  
  return true;
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// FUNÇÕES AUXILIARES
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

function pasteInput(selector, value) {
  const field = document.querySelector(selector);
  if (field) {
    field.focus();
    field.value = value;
    field.dispatchEvent(new Event("input", { bubbles: true }));
    field.dispatchEvent(new Event("change", { bubbles: true }));
    console.log(`✅ Pasted: ${value} into ${selector}`);
  } else {
    console.warn(`⚠️ Field not found: ${selector}`);
  }
}

function pasteDropdown(selectSelector, labelSelector, value) {
  const selectField = document.querySelector(selectSelector);
  const labelField = document.querySelector(labelSelector);
  
  if (value === "-Select-") {
    console.warn(`⚠️ Skipping "-Select-" for ${selectSelector}`);
    return;
  }
  
  if (selectField) {
    const option = Array.from(selectField.options).find(opt => 
      opt.text.trim() === value || opt.text.trim().includes(value)
    );
    
    if (option) {
      selectField.value = option.value;
      selectField.dispatchEvent(new Event("change", { bubbles: true }));
      console.log(`✅ Selected: ${value} in ${selectSelector}`);
      
      if (labelField) {
        labelField.textContent = value;
      }
    } else {
      console.warn(`⚠️ Option "${value}" not found in ${selectSelector}`);
    }
  } else {
    console.warn(`⚠️ Dropdown field not found: ${selectSelector}`);
  }
}

async function clickNextButton() {
  const nextBtn = Array.from(document.querySelectorAll("button"))
    .find(b => b.id.includes("j_idt") && 
               (b.innerText.includes("Next") || b.innerText.includes("Seguinte") || 
                b.className.includes("next")));
  
  if (nextBtn) {
    console.log("➡️ Clicking Next button...");
    nextBtn.click();
  } else {
    console.warn("⚠️ Next button not found");
  }
}

function wait(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function waitForElement(selector, timeout = 10000) {
  const startTime = Date.now();
  
  while (Date.now() - startTime < timeout) {
    const element = document.querySelector(selector);
    if (element && !element.disabled) {
      return element;
    }
    await wait(500);
  }
  
  throw new Error(`Timeout waiting for element: ${selector}`);
}

function b64toBlob(b64Data, contentType = '', sliceSize = 512) {
  const byteCharacters = atob(b64Data);
  const byteArrays = [];
  
  for (let offset = 0; offset < byteCharacters.length; offset += sliceSize) {
    const slice = byteCharacters.slice(offset, offset + sliceSize);
    const byteNumbers = new Array(slice.length);
    
    for (let i = 0; i < slice.length; i++) {
      byteNumbers[i] = slice.charCodeAt(i);
    }
    
    const byteArray = new Uint8Array(byteNumbers);
    byteArrays.push(byteArray);
  }
  
  return new Blob(byteArrays, { type: contentType });
}

function sendProgress(percent, message) {
  chrome.runtime.sendMessage({
    type: "progress",
    percent: percent,
    message: message
  });
}