window.location.replace("https://duropoint.github.io/qcheck-outlook/taskpane.html");
