const serverUrlInput = document.getElementById('serverUrl');
const apiKeyInput    = document.getElementById('apiKey');
const saveBtn        = document.getElementById('saveBtn');
const testBtn        = document.getElementById('testBtn');
const statusMsg      = document.getElementById('statusMsg');
const statusDot      = document.getElementById('statusDot');
const statusText     = document.getElementById('statusText');

// Load saved settings
chrome.storage.sync.get(['serverUrl', 'apiKey'], ({ serverUrl, apiKey }) => {
  if (serverUrl) serverUrlInput.value = serverUrl;
  if (apiKey)    apiKeyInput.value    = apiKey;
  setConnectionStatus(!!(serverUrl && apiKey));
});

// Save
saveBtn.addEventListener('click', () => {
  const url = serverUrlInput.value.trim().replace(/\/$/, '');
  const key = apiKeyInput.value.trim();
  if (!url) { setMsg('Please enter a server URL.', 'error'); return; }
  if (!key) { setMsg('Please enter an API key.',   'error'); return; }
  chrome.storage.sync.set({ serverUrl: url, apiKey: key }, () => {
    setMsg('Saved.', 'ok');
    setConnectionStatus(true);
    setTimeout(() => setMsg(''), 2000);
  });
});

// Test
testBtn.addEventListener('click', async () => {
  const url = serverUrlInput.value.trim().replace(/\/$/, '');
  const key = apiKeyInput.value.trim();
  if (!url || !key) { setMsg('Enter server URL and API key first.', 'error'); return; }

  testBtn.disabled = true;
  setMsg('Testing…', 'info');

  chrome.runtime.sendMessage(
    { type: 'euromar_request', method: 'GET', path: '/health' },
    (response) => {
      testBtn.disabled = false;
      if (chrome.runtime.lastError) {
        setMsg('Extension error: ' + chrome.runtime.lastError.message, 'error');
        setConnectionStatus(false);
        return;
      }
      if (!response) {
        setMsg('No response from background.', 'error');
        setConnectionStatus(false);
        return;
      }
      if (response.status === 401) {
        setMsg('API key rejected (401).', 'error');
        setConnectionStatus(false);
      } else {
        setMsg(`Connected — server responded (${response.status}).`, 'ok');
        setConnectionStatus(true);
      }
    }
  );
});

function setMsg(text, type) {
  statusMsg.textContent = text || '';
  statusMsg.className   = 'status-msg' + (type ? ' ' + type : '');
}

function setConnectionStatus(connected) {
  statusDot.className = 'status-dot ' + (connected ? 'connected' : 'disconnected');
  statusText.textContent = connected ? 'Connected' : 'Not configured';
}
