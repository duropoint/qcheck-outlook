// Euromar Toolkit — opens the side panel on toolbar click.
chrome.action.onClicked.addListener((tab) => {
  chrome.sidePanel.open({ tabId: tab.id });
});
