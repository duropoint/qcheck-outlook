// Euromar Toolkit — background service worker
//
// The entire application UI lives on the server (GitHub Pages).
// This extension is a launcher: clicking the toolbar icon opens the
// hosted web app in a popup window sized to match the Outlook task pane.
//
// To change the app URL (e.g. for a different environment):
//   chrome.storage.sync.set({ appUrl: 'https://your-server.example.com/' })

const DEFAULT_APP_URL = 'https://duropoint.github.io/qcheck-outlook/';

chrome.action.onClicked.addListener(async () => {
  const { appUrl } = await chrome.storage.sync.get('appUrl');
  const url = (appUrl || DEFAULT_APP_URL).replace(/\/$/, '/');

  chrome.windows.create({
    url,
    type:    'popup',
    width:   380,
    height:  680,
    focused: true
  });
});
