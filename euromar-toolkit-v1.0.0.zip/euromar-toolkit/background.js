// Euromar Toolkit — background service worker
// Handles all server-side API requests on behalf of the popup and content scripts.
// All business logic lives server-side; this worker is the authenticated bridge.

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === 'euromar_request') {
    handleRequest(msg, sendResponse);
    return true; // keep message channel open for async response
  }
  return false;
});

async function handleRequest(msg, sendResponse) {
  try {
    const { serverUrl, apiKey } = await chrome.storage.sync.get(['serverUrl', 'apiKey']);

    if (!serverUrl || !apiKey) {
      sendResponse({ ok: false, status: 0, error: 'Server not configured. Open the extension to set up.' });
      return;
    }

    const url = serverUrl.replace(/\/$/, '') + (msg.path || '/');

    const headers = {
      'X-API-Key': apiKey,
      ...(msg.headers || {})
    };

    const options = { method: msg.method || 'GET', headers };

    if (msg.body !== undefined) {
      headers['Content-Type'] = 'application/json';
      options.body = JSON.stringify(msg.body);
    }

    const resp = await fetch(url, options);
    const contentType = resp.headers.get('content-type') || '';

    let data;
    if (contentType.includes('application/json')) {
      data = await resp.json();
    } else if (contentType.includes('application/pdf') || contentType.includes('octet-stream')) {
      // Return binary as base64 so it survives the message channel
      const buffer = await resp.arrayBuffer();
      data = btoa(String.fromCharCode(...new Uint8Array(buffer)));
    } else {
      data = await resp.text();
    }

    sendResponse({ ok: resp.ok, status: resp.status, data });
  } catch (err) {
    sendResponse({ ok: false, status: 0, error: err.message });
  }
}
