// Euromar Toolkit — background service worker
// Opens the server-hosted web app in Chrome's side panel.

chrome.action.onClicked.addListener((tab) => {
  chrome.sidePanel.open({ tabId: tab.id });
});
